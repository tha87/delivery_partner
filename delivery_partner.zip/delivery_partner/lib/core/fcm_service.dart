import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'api_service.dart';

/// Handles background FCM messages (must be top-level function)
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint('🔔 Background message: ${message.notification?.title}');
}

/// FCM service for Delivery Partner app
class FcmService {
  static final FcmService _instance = FcmService._internal();
  factory FcmService() => _instance;
  FcmService._internal();

  final FirebaseMessaging _messaging = FirebaseMessaging.instance;
  String? _currentToken;

  /// Initialize FCM — call once from main() after Firebase.initializeApp()
  Future<void> init({
    void Function(RemoteMessage)? onForegroundMessage,
    void Function(RemoteMessage)? onMessageOpenedApp,
  }) async {
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    debugPrint('🔔 Notification permission: ${settings.authorizationStatus}');

    if (settings.authorizationStatus == AuthorizationStatus.denied) return;

    if (Platform.isIOS) {
      await _messaging.getAPNSToken();
    }

    if (onForegroundMessage != null) {
      FirebaseMessaging.onMessage.listen(onForegroundMessage);
    }

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      debugPrint('🔔 Opened from notification: ${message.notification?.title}');
      onMessageOpenedApp?.call(message);
    });

    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      onMessageOpenedApp?.call(initialMessage);
    }

    _messaging.onTokenRefresh.listen((newToken) {
      _currentToken = newToken;
      _registerTokenWithBackend(newToken);
    });
  }

  /// Register FCM token with backend — call after login
  Future<void> registerToken() async {
    try {
      final token = await _messaging.getToken();
      if (token == null) return;
      _currentToken = token;
      debugPrint('🔔 FCM token: ${token.substring(0, 20)}...');
      await _registerTokenWithBackend(token);
    } catch (e) {
      debugPrint('🔔 FCM registerToken error: $e');
    }
  }

  /// Unregister token — call on logout
  Future<void> unregisterToken() async {
    try {
      if (_currentToken != null) {
        await ApiService().post(
          '/notifications/unregister-device/',
          body: {'fcm_token': _currentToken},
        );
      }
    } catch (e) {
      debugPrint('🔔 FCM unregisterToken error: $e');
    }
  }

  Future<void> _registerTokenWithBackend(String token) async {
    try {
      final result = await ApiService().post(
        '/notifications/register-device/',
        body: {
          'fcm_token': token,
          'device_type': Platform.isIOS ? 'IOS' : 'ANDROID',
        },
      );
      if (result.isSuccess) {
        debugPrint('🔔 FCM token registered with backend');
      } else {
        debugPrint('🔔 FCM token registration failed: ${result.error}');
      }
    } catch (e) {
      debugPrint('🔔 FCM backend registration error: $e');
    }
  }
}
