import 'dart:io';

class AppConstants {
  static const String appName = 'Delivery Partner';
  static const String roleDeliveryBoy = 'DELIVERY_BOY';

  // API Configuration
  static String get apiBaseUrl {
    if (Platform.isAndroid) {
      return 'http://10.0.2.2:8000/api/v1';
    }
    return 'http://127.0.0.1:8000/api/v1';
  }
  
  // Auth Endpoints (Accounts App)
  static const String loginEndpoint = '/accounts/auth/verify-otp/'; 
  static const String sendOtpEndpoint = '/accounts/auth/send-otp/';
  static const String refreshTokenEndpoint = '/auth/token/refresh/';
  static const String profileEndpoint = '/accounts/users/me/';
  
  // Delivery Endpoints
  static const String deliveryAssignmentsEndpoint = '/delivery/assignments/';
  static const String completeDeliveryEndpoint = '/delivery/assignments/';

  // SharedPreferences Keys
  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userDataKey = 'user_data';
}
