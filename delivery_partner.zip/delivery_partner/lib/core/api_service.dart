import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

/// API Response wrapper for consistent error handling
class ApiResponse<T> {
  final T? data;
  final String? error;
  final int statusCode;
  final bool isSuccess;

  ApiResponse({
    this.data,
    this.error,
    required this.statusCode,
  }) : isSuccess = statusCode >= 200 && statusCode < 300;

  factory ApiResponse.success(T data, int statusCode) {
    return ApiResponse(data: data, statusCode: statusCode);
  }

  factory ApiResponse.error(String error, int statusCode) {
    return ApiResponse(error: error, statusCode: statusCode);
  }
}

/// Central API service for making authenticated requests to Django backend
class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  final String _baseUrl = AppConstants.apiBaseUrl;

  /// Get stored access token
  Future<String?> getAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.accessTokenKey);
  }

  /// Get stored refresh token
  Future<String?> getRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.refreshTokenKey);
  }

  /// Save tokens to SharedPreferences
  Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.accessTokenKey, accessToken);
    await prefs.setString(AppConstants.refreshTokenKey, refreshToken);
  }

  /// Clear all stored tokens
  Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConstants.accessTokenKey);
    await prefs.remove(AppConstants.refreshTokenKey);
    await prefs.remove(AppConstants.userDataKey);
  }

  /// Build headers with optional JWT token
  Future<Map<String, String>> _getHeaders({bool requiresAuth = true}) async {
    final headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (requiresAuth) {
      final token = await getAccessToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    return headers;
  }

  /// Attempt to refresh the access token
  Future<bool> refreshAccessToken() async {
    try {
      final refreshToken = await getRefreshToken();
      if (refreshToken == null) return false;

      final response = await http.post(
        Uri.parse('$_baseUrl${AppConstants.refreshTokenEndpoint}'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refresh': refreshToken}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(AppConstants.accessTokenKey, data['access']);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  /// Generic GET request
  Future<ApiResponse<Map<String, dynamic>>> get(
    String endpoint, {
    Map<String, String>? queryParams,
    bool requiresAuth = true,
  }) async {
    try {
      var uri = Uri.parse('$_baseUrl$endpoint');
      if (queryParams != null && queryParams.isNotEmpty) {
        uri = uri.replace(queryParameters: queryParams);
      }

      final headers = await _getHeaders(requiresAuth: requiresAuth);
      var response = await http.get(uri, headers: headers);

      // If unauthorized, try refreshing the token
      if (response.statusCode == 401 && requiresAuth) {
        final refreshed = await refreshAccessToken();
        if (refreshed) {
          final newHeaders = await _getHeaders(requiresAuth: true);
          response = await http.get(uri, headers: newHeaders);
        }
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final data = jsonDecode(response.body);
        return ApiResponse.success(data as Map<String, dynamic>, response.statusCode);
      } else {
        final errorMsg = _parseError(response.body);
        return ApiResponse.error(errorMsg, response.statusCode);
      }
    } catch (e) {
      return ApiResponse.error(e.toString(), 0);
    }
  }

  /// Generic GET request returning a list
  Future<ApiResponse<List<dynamic>>> getList(
    String endpoint, {
    Map<String, String>? queryParams,
    bool requiresAuth = true,
  }) async {
    try {
      var uri = Uri.parse('$_baseUrl$endpoint');
      if (queryParams != null && queryParams.isNotEmpty) {
        uri = uri.replace(queryParameters: queryParams);
      }

      final headers = await _getHeaders(requiresAuth: requiresAuth);
      var response = await http.get(uri, headers: headers);

      // If unauthorized, try refreshing the token
      if (response.statusCode == 401 && requiresAuth) {
        final refreshed = await refreshAccessToken();
        if (refreshed) {
          final newHeaders = await _getHeaders(requiresAuth: true);
          response = await http.get(uri, headers: newHeaders);
        }
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        final data = jsonDecode(response.body);
        // Handle paginated responses
        if (data is Map && data.containsKey('results')) {
          return ApiResponse.success(data['results'] as List<dynamic>, response.statusCode);
        }
        return ApiResponse.success(data as List<dynamic>, response.statusCode);
      } else {
        final errorMsg = _parseError(response.body);
        return ApiResponse.error(errorMsg, response.statusCode);
      }
    } catch (e) {
      return ApiResponse.error(e.toString(), 0);
    }
  }

  /// Generic POST request
  Future<ApiResponse<Map<String, dynamic>>> post(
    String endpoint, {
    Map<String, dynamic>? body,
    bool requiresAuth = true,
  }) async {
    try {
      final uri = Uri.parse('$_baseUrl$endpoint');
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      
      var response = await http.post(
        uri,
        headers: headers,
        body: body != null ? jsonEncode(body) : null,
      );

      // If unauthorized, try refreshing the token
      if (response.statusCode == 401 && requiresAuth) {
        final refreshed = await refreshAccessToken();
        if (refreshed) {
          final newHeaders = await _getHeaders(requiresAuth: true);
          response = await http.post(
            uri,
            headers: newHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
        }
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (response.body.isEmpty) {
          return ApiResponse.success({}, response.statusCode);
        }
        final data = jsonDecode(response.body);
        return ApiResponse.success(data as Map<String, dynamic>, response.statusCode);
      } else {
        final errorMsg = _parseError(response.body);
        return ApiResponse.error(errorMsg, response.statusCode);
      }
    } catch (e) {
      return ApiResponse.error(e.toString(), 0);
    }
  }

  /// Multipart POST request for file uploads (like proof images)
  Future<ApiResponse<Map<String, dynamic>>> postMultipart(
    String endpoint, {
    Map<String, String>? fields,
    required String filePath,
    required String fileFieldName,
    bool requiresAuth = true,
  }) async {
    try {
      final uri = Uri.parse('$_baseUrl$endpoint');
      final token = await getAccessToken();

      var request = http.MultipartRequest('POST', uri);

      // Add authorization header
      if (requiresAuth && token != null) {
        request.headers['Authorization'] = 'Bearer $token';
      }

      // Add text fields
      if (fields != null) {
        request.fields.addAll(fields);
      }

      // Add file
      final file = File(filePath);
      final fileName = file.path.split('/').last;
      final extension = fileName.split('.').last.toLowerCase();
      
      // Determine content type
      MediaType? mediaType;
      if (['jpg', 'jpeg'].contains(extension)) {
        mediaType = MediaType('image', 'jpeg');
      } else if (extension == 'png') {
        mediaType = MediaType('image', 'png');
      } else if (extension == 'webp') {
        mediaType = MediaType('image', 'webp');
      }

      request.files.add(await http.MultipartFile.fromPath(
        fileFieldName,
        filePath,
        contentType: mediaType,
      ));

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (response.body.isEmpty) {
          return ApiResponse.success({}, response.statusCode);
        }
        final data = jsonDecode(response.body);
        return ApiResponse.success(data as Map<String, dynamic>, response.statusCode);
      } else {
        final errorMsg = _parseError(response.body);
        return ApiResponse.error(errorMsg, response.statusCode);
      }
    } catch (e) {
      return ApiResponse.error(e.toString(), 0);
    }
  }

  /// Generic PATCH request
  Future<ApiResponse<Map<String, dynamic>>> patch(
    String endpoint, {
    Map<String, dynamic>? body,
    bool requiresAuth = true,
  }) async {
    try {
      final uri = Uri.parse('$_baseUrl$endpoint');
      final headers = await _getHeaders(requiresAuth: requiresAuth);
      
      var response = await http.patch(
        uri,
        headers: headers,
        body: body != null ? jsonEncode(body) : null,
      );

      // If unauthorized, try refreshing the token
      if (response.statusCode == 401 && requiresAuth) {
        final refreshed = await refreshAccessToken();
        if (refreshed) {
          final newHeaders = await _getHeaders(requiresAuth: true);
          response = await http.patch(
            uri,
            headers: newHeaders,
            body: body != null ? jsonEncode(body) : null,
          );
        }
      }

      if (response.statusCode >= 200 && response.statusCode < 300) {
        if (response.body.isEmpty) {
          return ApiResponse.success({}, response.statusCode);
        }
        final data = jsonDecode(response.body);
        return ApiResponse.success(data as Map<String, dynamic>, response.statusCode);
      } else {
        final errorMsg = _parseError(response.body);
        return ApiResponse.error(errorMsg, response.statusCode);
      }
    } catch (e) {
      return ApiResponse.error(e.toString(), 0);
    }
  }

  /// Parse error message from response body
  String _parseError(String responseBody) {
    try {
      final data = jsonDecode(responseBody);
      if (data is Map) {
        // Django REST framework typically returns errors in these formats
        if (data.containsKey('detail')) {
          return data['detail'].toString();
        }
        if (data.containsKey('error')) {
          return data['error'].toString();
        }
        if (data.containsKey('message')) {
          return data['message'].toString();
        }
        // Handle field-level errors
        if (data.containsKey('non_field_errors')) {
          return (data['non_field_errors'] as List).join(', ');
        }
        // Return first field error
        for (var value in data.values) {
          if (value is List && value.isNotEmpty) {
            return value.first.toString();
          }
          if (value is String) {
            return value;
          }
        }
      }
      return responseBody;
    } catch (e) {
      return responseBody;
    }
  }
}
