/// Status of a delivery assignment
enum DeliveryAssignmentStatus {
  assigned,
  accepted,
  inTransit,
  completed,
  failed,
  cancelled,
}

extension DeliveryAssignmentStatusExt on DeliveryAssignmentStatus {
  String get value {
    switch (this) {
      case DeliveryAssignmentStatus.assigned:
        return 'assigned';
      case DeliveryAssignmentStatus.accepted:
        return 'accepted';
      case DeliveryAssignmentStatus.inTransit:
        return 'in_transit';
      case DeliveryAssignmentStatus.completed:
        return 'completed';
      case DeliveryAssignmentStatus.failed:
        return 'failed';
      case DeliveryAssignmentStatus.cancelled:
        return 'cancelled';
    }
  }

  static DeliveryAssignmentStatus fromString(String value) {
    switch (value.toLowerCase()) {
      case 'assigned':
        return DeliveryAssignmentStatus.assigned;
      case 'accepted':
        return DeliveryAssignmentStatus.accepted;
      case 'in_transit':
      case 'in-transit':
      case 'intransit':
        return DeliveryAssignmentStatus.inTransit;
      case 'completed':
        return DeliveryAssignmentStatus.completed;
      case 'failed':
        return DeliveryAssignmentStatus.failed;
      case 'cancelled':
      case 'canceled':
        return DeliveryAssignmentStatus.cancelled;
      default:
        return DeliveryAssignmentStatus.assigned;
    }
  }

  String get displayName {
    switch (this) {
      case DeliveryAssignmentStatus.assigned:
        return 'Assigned';
      case DeliveryAssignmentStatus.accepted:
        return 'Accepted';
      case DeliveryAssignmentStatus.inTransit:
        return 'In Transit';
      case DeliveryAssignmentStatus.completed:
        return 'Completed';
      case DeliveryAssignmentStatus.failed:
        return 'Failed';
      case DeliveryAssignmentStatus.cancelled:
        return 'Cancelled';
    }
  }
}

/// Customer address details
class CustomerAddress {
  final String? addressLine1;
  final String? addressLine2;
  final String? city;
  final String? state;
  final String? pincode;
  final double? latitude;
  final double? longitude;

  CustomerAddress({
    this.addressLine1,
    this.addressLine2,
    this.city,
    this.state,
    this.pincode,
    this.latitude,
    this.longitude,
  });

  factory CustomerAddress.fromJson(Map<String, dynamic> json) {
    return CustomerAddress(
      addressLine1: json['address_line1']?.toString() ?? json['address']?.toString(),
      addressLine2: json['address_line2']?.toString(),
      city: json['city']?.toString(),
      state: json['state']?.toString(),
      pincode: json['pincode']?.toString() ?? json['postal_code']?.toString(),
      latitude: json['latitude'] != null ? double.tryParse(json['latitude'].toString()) : null,
      longitude: json['longitude'] != null ? double.tryParse(json['longitude'].toString()) : null,
    );
  }

  String get fullAddress {
    final parts = <String>[];
    if (addressLine1 != null && addressLine1!.isNotEmpty) parts.add(addressLine1!);
    if (addressLine2 != null && addressLine2!.isNotEmpty) parts.add(addressLine2!);
    if (city != null && city!.isNotEmpty) parts.add(city!);
    if (state != null && state!.isNotEmpty) parts.add(state!);
    if (pincode != null && pincode!.isNotEmpty) parts.add(pincode!);
    return parts.join(', ');
  }
}

/// Booking item within an assignment
class BookingItem {
  final int? id;
  final String? productName;
  final String? cylinderType;
  final int quantity;
  final double? unitPrice;
  final double? totalPrice;

  BookingItem({
    this.id,
    this.productName,
    this.cylinderType,
    required this.quantity,
    this.unitPrice,
    this.totalPrice,
  });

  factory BookingItem.fromJson(Map<String, dynamic> json) {
    return BookingItem(
      id: json['id'],
      productName: json['product_name']?.toString() ?? json['product']?['name']?.toString(),
      cylinderType: json['cylinder_type']?.toString() ?? json['type']?.toString(),
      quantity: json['quantity'] ?? 1,
      unitPrice: json['unit_price'] != null ? double.tryParse(json['unit_price'].toString()) : null,
      totalPrice: json['total_price'] != null ? double.tryParse(json['total_price'].toString()) : null,
    );
  }
}

/// Main delivery assignment model matching Django DeliveryAssignment
class DeliveryAssignment {
  final int id;
  final int? bookingId;
  final String? bookingReference;
  
  // Customer info
  final String customerName;
  final String customerPhone;
  final CustomerAddress? address;
  
  // Assignment details
  final DeliveryAssignmentStatus status;
  final DateTime? scheduledDate;
  final String? scheduledTimeSlot;
  final DateTime? assignedAt;
  final DateTime? completedAt;
  
  // Items
  final List<BookingItem> items;
  final String? cylinderType;
  final int quantity;
  
  // Payment
  final double amount;
  final bool isCod;
  final bool isPaid;
  
  // Pickup location (warehouse/plant)
  final String? pickupAddress;
  final double? pickupLatitude;
  final double? pickupLongitude;
  
  // Notes
  final String? notes;
  final String? specialInstructions;

  DeliveryAssignment({
    required this.id,
    this.bookingId,
    this.bookingReference,
    required this.customerName,
    required this.customerPhone,
    this.address,
    required this.status,
    this.scheduledDate,
    this.scheduledTimeSlot,
    this.assignedAt,
    this.completedAt,
    this.items = const [],
    this.cylinderType,
    required this.quantity,
    required this.amount,
    required this.isCod,
    this.isPaid = false,
    this.pickupAddress,
    this.pickupLatitude,
    this.pickupLongitude,
    this.notes,
    this.specialInstructions,
  });

  factory DeliveryAssignment.fromJson(Map<String, dynamic> json) {
    // Parse items if present
    List<BookingItem> items = [];
    if (json['items'] != null) {
      items = (json['items'] as List).map((e) => BookingItem.fromJson(e)).toList();
    }

    // Parse booking nested data if present
    final booking = json['booking'] as Map<String, dynamic>?;
    
    // Parse customer data (could be nested or flat)
    final customer = json['customer'] ?? booking?['customer'];
    String customerName = '';
    String customerPhone = '';
    
    if (customer is Map) {
      customerName = customer['name']?.toString() ?? 
                    '${customer['first_name'] ?? ''} ${customer['last_name'] ?? ''}'.trim();
      customerPhone = customer['phone']?.toString() ?? customer['mobile']?.toString() ?? '';
    } else {
      customerName = json['customer_name']?.toString() ?? booking?['customer_name']?.toString() ?? '';
      customerPhone = json['customer_phone']?.toString() ?? booking?['customer_phone']?.toString() ?? '';
    }

    // Parse address
    CustomerAddress? address;
    if (json['delivery_address'] != null) {
      address = CustomerAddress.fromJson(json['delivery_address']);
    } else if (json['address'] != null && json['address'] is Map) {
      address = CustomerAddress.fromJson(json['address']);
    } else if (booking?['address'] != null) {
      address = CustomerAddress.fromJson(booking!['address']);
    }

    return DeliveryAssignment(
      id: json['id'] ?? 0,
      bookingId: json['booking_id'] ?? booking?['id'],
      bookingReference: json['booking_reference'] ?? booking?['reference'] ?? json['order_id']?.toString(),
      customerName: customerName,
      customerPhone: customerPhone,
      address: address,
      status: DeliveryAssignmentStatusExt.fromString(json['status']?.toString() ?? 'assigned'),
      scheduledDate: json['scheduled_date'] != null 
          ? DateTime.tryParse(json['scheduled_date'].toString())
          : (json['scheduled_at'] != null ? DateTime.tryParse(json['scheduled_at'].toString()) : null),
      scheduledTimeSlot: json['time_slot']?.toString() ?? json['scheduled_time_slot']?.toString(),
      assignedAt: json['assigned_at'] != null ? DateTime.tryParse(json['assigned_at'].toString()) : null,
      completedAt: json['completed_at'] != null ? DateTime.tryParse(json['completed_at'].toString()) : null,
      items: items,
      cylinderType: json['cylinder_type']?.toString() ?? 
                   (items.isNotEmpty ? items.first.cylinderType : json['product_type']?.toString()),
      quantity: json['quantity'] ?? 
               (items.isNotEmpty ? items.fold<int>(0, (sum, item) => sum + item.quantity) : 1),
      amount: json['amount'] != null 
          ? double.tryParse(json['amount'].toString()) ?? 0.0 
          : (json['total_amount'] != null ? double.tryParse(json['total_amount'].toString()) ?? 0.0 : 0.0),
      isCod: json['is_cod'] ?? json['payment_method'] == 'cod' ?? false,
      isPaid: json['is_paid'] ?? json['payment_status'] == 'paid' ?? false,
      pickupAddress: json['pickup_address']?.toString(),
      pickupLatitude: json['pickup_latitude'] != null ? double.tryParse(json['pickup_latitude'].toString()) : null,
      pickupLongitude: json['pickup_longitude'] != null ? double.tryParse(json['pickup_longitude'].toString()) : null,
      notes: json['notes']?.toString(),
      specialInstructions: json['special_instructions']?.toString() ?? booking?['special_instructions']?.toString(),
    );
  }

  /// Get display address
  String get displayAddress {
    if (address != null) {
      return address!.fullAddress;
    }
    return 'Address not available';
  }

  /// Get display cylinder info
  String get cylinderInfo {
    if (items.isNotEmpty) {
      return items.map((e) => '${e.quantity}x ${e.cylinderType ?? e.productName}').join(', ');
    }
    return '$quantity x ${cylinderType ?? 'Cylinder'}';
  }

  /// Check if delivery is pending (assigned but not started)
  bool get isPending => status == DeliveryAssignmentStatus.assigned;

  /// Check if delivery is in progress
  bool get isInProgress => status == DeliveryAssignmentStatus.accepted || 
                           status == DeliveryAssignmentStatus.inTransit;

  /// Check if delivery is complete
  bool get isCompleted => status == DeliveryAssignmentStatus.completed;

  /// Get product name
  String get productName {
    if (items.isNotEmpty) {
      return items.first.productName ?? 'Gas Cylinder';
    }
    return cylinderType ?? 'Gas Cylinder';
  }
}
