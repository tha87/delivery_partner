/// Model for delivery proof submission
class DeliveryProof {
  final String assignmentId;
  final String otp;
  final String? proofImagePath;
  final double? latitude;
  final double? longitude;
  final bool emptyCylinderCollected;
  final bool cylinderConditionGood;
  final String? damageImagePath;
  final double? amountCollected;
  final String? customerSignaturePath;
  final String? notes;
  final DateTime timestamp;

  DeliveryProof({
    required this.assignmentId,
    required this.otp,
    this.proofImagePath,
    this.latitude,
    this.longitude,
    this.emptyCylinderCollected = true,
    this.cylinderConditionGood = true,
    this.damageImagePath,
    this.amountCollected,
    this.customerSignaturePath,
    this.notes,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();

  /// Convert to JSON for API submission (without file)
  Map<String, dynamic> toJson() {
    return {
      'otp': otp,
      'latitude': latitude,
      'longitude': longitude,
      'empty_cylinder_collected': emptyCylinderCollected,
      'cylinder_condition_good': cylinderConditionGood,
      'amount_collected': amountCollected,
      'notes': notes,
      'completed_at': timestamp.toIso8601String(),
    };
  }

  /// Convert to form fields for multipart request
  Map<String, String> toFormFields() {
    final fields = <String, String>{
      'otp': otp,
      'empty_cylinder_collected': emptyCylinderCollected.toString(),
      'cylinder_condition_good': cylinderConditionGood.toString(),
      'completed_at': timestamp.toIso8601String(),
    };

    if (latitude != null) {
      fields['latitude'] = latitude.toString();
    }
    if (longitude != null) {
      fields['longitude'] = longitude.toString();
    }
    if (amountCollected != null) {
      fields['amount_collected'] = amountCollected.toString();
    }
    if (notes != null && notes!.isNotEmpty) {
      fields['notes'] = notes!;
    }

    return fields;
  }
}

/// Response after completing a delivery
class DeliveryCompletionResponse {
  final bool success;
  final String? message;
  final double? earningsAdded;
  final int? newTotalDeliveries;

  DeliveryCompletionResponse({
    required this.success,
    this.message,
    this.earningsAdded,
    this.newTotalDeliveries,
  });

  factory DeliveryCompletionResponse.fromJson(Map<String, dynamic> json) {
    return DeliveryCompletionResponse(
      success: json['success'] ?? true,
      message: json['message']?.toString(),
      earningsAdded: json['earnings_added'] != null 
          ? double.tryParse(json['earnings_added'].toString()) 
          : null,
      newTotalDeliveries: json['total_deliveries'],
    );
  }

  factory DeliveryCompletionResponse.error(String message) {
    return DeliveryCompletionResponse(
      success: false,
      message: message,
    );
  }
}
