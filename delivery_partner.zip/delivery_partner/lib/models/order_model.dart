
class Order {
  final String id;
  final String customerName;
  final String address;
  final String phone;
  final String cylinderType;
  final int quantity;
  final String status; // Assigned, In Progress, Delivered
  final double amount;
  final bool isCod;

  Order({
    required this.id,
    required this.customerName,
    required this.address,
    required this.phone,
    required this.cylinderType,
    required this.quantity,
    required this.status,
    required this.amount,
    required this.isCod,
  });
}
