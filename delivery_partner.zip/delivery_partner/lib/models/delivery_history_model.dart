enum DeliveryStatus {
  delivered,
  failed,
  returned,
}

class DeliveryHistory {
  final String id;
  final String orderId;
  final String customerName;
  final String phone;
  final String address;
  final String area;
  final String cylinderType;
  final int quantity;
  final DateTime deliveryDateTime;
  final DeliveryStatus status;

  // Proof of Delivery
  final String? otpUsed;
  final List<String> deliveryPhotos;
  final double? latitude;
  final double? longitude;

  // Cylinder Return
  final bool emptyCylinderCollected;
  final bool cylinderConditionGood;
  final String? damagePhotoUrl;

  // Payment
  final bool isCod;
  final double amount;
  final double? amountCollected;

  // Ratings
  final int? rating;

  DeliveryHistory({
    required this.id,
    required this.orderId,
    required this.customerName,
    required this.phone,
    required this.address,
    required this.area,
    required this.cylinderType,
    required this.quantity,
    required this.deliveryDateTime,
    required this.status,
    this.otpUsed,
    this.deliveryPhotos = const [],
    this.latitude,
    this.longitude,
    this.emptyCylinderCollected = true,
    this.cylinderConditionGood = true,
    this.damagePhotoUrl,
    required this.isCod,
    required this.amount,
    this.amountCollected,
    this.rating,
  });
}
