import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../features/auth/auth_provider.dart';
import '../features/auth/login_screen.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/delivery/delivery_list_screen.dart';
import '../features/delivery/order_details_screen.dart';
import '../features/delivery/delivery_process_screen.dart';
import '../features/delivery/presentation/screens/assigned_orders_screen.dart'; // Import new screen
import '../features/support/support_screen.dart';
import '../features/history/history_list_screen.dart';
import '../features/history/history_detail_screen.dart';
import '../features/security/face_verification_screen.dart';
import '../features/security/face_verification_service.dart';
import '../features/earnings/smart_earnings_screen.dart';
import '../features/wallet/wallet_screen.dart';
import '../features/wallet/withdraw_screen.dart';
import '../features/wallet/withdrawal_history_screen.dart';
import '../models/delivery_assignment_model.dart';
import '../models/delivery_history_model.dart';

class AppRouter {
  final AuthProvider authProvider;

  AppRouter(this.authProvider);

  GoRouter get router => GoRouter(
    refreshListenable: authProvider,
    redirect: (context, state) {
      final isLoggedIn = authProvider.isAuthenticated;
      final isLoggingIn = state.uri.toString() == '/login';

      if (!isLoggedIn && !isLoggingIn) return '/login';
      if (isLoggedIn && isLoggingIn) return '/';
      return null;
    },
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/delivery/assigned', // New Route
        builder: (context, state) => const AssignedOrdersScreen(),
      ),
      GoRoute(
        path: '/delivery/list',
        builder: (context, state) => const DeliveryListScreen(),
      ),
      GoRoute(
        path: '/delivery/details/:id',
        builder: (context, state) {
          final order = state.extra as DeliveryAssignment;
          return OrderDetailsScreen(order: order);
        },
      ),
      GoRoute(
        path: '/delivery/process/:id',
        builder: (context, state) {
          final order = state.extra as DeliveryAssignment;
          return DeliveryProcessScreen(order: order);
        },
      ),
      GoRoute(
        path: '/support',
        builder: (context, state) => const SupportScreen(),
      ),
      GoRoute(
        path: '/earnings',
        builder: (context, state) => const SmartEarningsScreen(),
      ),
      GoRoute(
        path: '/history',
        builder: (context, state) => const HistoryListScreen(),
      ),
      GoRoute(
        path: '/history/detail/:id',
        builder: (context, state) {
          final history = state.extra as DeliveryHistory;
          return HistoryDetailScreen(history: history);
        },
      ),
      GoRoute(
        path: '/verify-face',
        builder: (context, state) {
          final type = state.extra as VerificationType? ?? VerificationType.shiftStart;
          return FaceVerificationScreen(verificationType: type);
        },
      ),
      GoRoute(
        path: '/wallet',
        builder: (context, state) => const WalletScreen(),
      ),
      GoRoute(
        path: '/wallet/withdraw',
        builder: (context, state) => const WithdrawScreen(),
      ),
      GoRoute(
        path: '/wallet/history',
        builder: (context, state) => const WithdrawalHistoryScreen(),
      ),
    ],
  );
}
