import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/api_service.dart';
import '../../core/constants.dart';
import '../../core/fcm_service.dart';

class AuthProvider extends ChangeNotifier {
  bool _isAuthenticated = false;
  bool _isLoading = false;
  String? _error;
  Map<String, dynamic>? _userData;
  final ApiService _apiService = ApiService();

  bool get isAuthenticated => _isAuthenticated;
  bool get isLoading => _isLoading;
  String? get error => _error;
  Map<String, dynamic>? get userData => _userData;
  String? get userName => _userData?['name'] ?? _userData?['first_name'];
  String? get userPhone => _userData?['phone'] ?? _userData?['mobile'];

  AuthProvider() {
    _checkAuthStatus();
  }

  /// Check if user is already logged in on app start
  Future<void> _checkAuthStatus() async {
    final token = await _apiService.getAccessToken();
    if (token != null) {
      // Try to fetch user profile to validate token
      final response = await _apiService.get(AppConstants.profileEndpoint);
      if (response.isSuccess && response.data != null) {
        _userData = response.data;
        _isAuthenticated = true;
        FcmService().registerToken(); // Re-register on app restart
        notifyListeners();
      } else {
        // Token might be expired, try refresh
        final refreshed = await _apiService.refreshAccessToken();
        if (refreshed) {
          final retryResponse = await _apiService.get(AppConstants.profileEndpoint);
          if (retryResponse.isSuccess && retryResponse.data != null) {
            _userData = retryResponse.data;
            _isAuthenticated = true;
            notifyListeners();
            return;
          }
        }
        // Clear invalid tokens
        await _apiService.clearTokens();
      }
    }
  }

  /// Request OTP for phone number
  Future<bool> requestOtp(String phoneNumber) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await _apiService.post(
        AppConstants.sendOtpEndpoint,
        body: {'phone_number': phoneNumber},
        requiresAuth: false,
      );

      _isLoading = false;
      
      if (response.isSuccess) {
        notifyListeners();
        return true;
      } else {
        _error = response.error ?? 'Failed to send OTP';
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  /// Login with phone and OTP
  Future<bool> login(String phone, String otp) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await _apiService.post(
        AppConstants.loginEndpoint,
        body: {
          'phone_number': phone,
          'otp': otp,
        },
        requiresAuth: false,
      );

      _isLoading = false;

      if (response.isSuccess && response.data != null) {
        final data = response.data!;
        
        // Check if user has DELIVERY_BOY role
        final role = data['role'] ?? data['user']?['role'];
        if (role != AppConstants.roleDeliveryBoy) {
          _error = 'This app is only for delivery partners';
          notifyListeners();
          return false;
        }

        // Extract tokens
        final accessToken = data['access'] ?? data['access_token'] ?? data['token'];
        final refreshToken = data['refresh'] ?? data['refresh_token'];

        if (accessToken != null) {
          await _apiService.saveTokens(
            accessToken: accessToken,
            refreshToken: refreshToken ?? '',
          );

          // Store user data
          _userData = data['user'] ?? data;
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString(AppConstants.userDataKey, jsonEncode(_userData));

          _isAuthenticated = true;
          FcmService().registerToken(); // Register FCM token on login
          notifyListeners();
          return true;
        } else {
          _error = 'Invalid response from server';
          notifyListeners();
          return false;
        }
      } else {
        _error = response.error ?? 'Login failed';
        notifyListeners();
        return false;
      }
    } catch (e) {
      _isLoading = false;
      _error = e.toString();
      notifyListeners();
      return false;
    }
  }

  /// Logout and clear all stored data
  Future<void> logout() async {
    await FcmService().unregisterToken();
    await _apiService.clearTokens();
    _isAuthenticated = false;
    _userData = null;
    _error = null;
    notifyListeners();
  }

  /// Clear any error messages
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// Get access token for other services
  Future<String?> getAccessToken() async {
    return await _apiService.getAccessToken();
  }
}
