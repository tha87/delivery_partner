import '../../core/api_service.dart';
import '../../core/constants.dart';
import '../../models/delivery_assignment_model.dart';
import '../../models/delivery_proof_model.dart';

/// Service for fetching and managing delivery assignments from Django API
class DeliveryService {
  final ApiService _api = ApiService();

  /// Fetch all assigned deliveries for the current delivery partner
  /// Returns deliveries with status: assigned, accepted, in_transit
  Future<List<DeliveryAssignment>> getAssignedDeliveries() async {
    try {
      final response = await _api.getList(
        AppConstants.deliveryAssignmentsEndpoint,
        queryParams: {'status__in': 'assigned,accepted,in_transit'},
      );

      if (response.isSuccess && response.data != null) {
        return response.data!
            .map((json) => DeliveryAssignment.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return [];
    } catch (e) {
      print('Error fetching assigned deliveries: $e');
      return [];
    }
  }

  /// Fetch pending deliveries (assigned but not yet picked up)
  Future<List<DeliveryAssignment>> getPendingDeliveries() async {
    try {
      final response = await _api.getList(
        AppConstants.deliveryAssignmentsEndpoint,
        queryParams: {'status': 'assigned'},
      );

      if (response.isSuccess && response.data != null) {
        return response.data!
            .map((json) => DeliveryAssignment.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return [];
    } catch (e) {
      print('Error fetching pending deliveries: $e');
      return [];
    }
  }

  /// Fetch completed deliveries
  Future<List<DeliveryAssignment>> getCompletedDeliveries({
    DateTime? fromDate,
    DateTime? toDate,
  }) async {
    try {
      final queryParams = <String, String>{'status': 'completed'};
      
      if (fromDate != null) {
        queryParams['completed_at__gte'] = fromDate.toIso8601String().split('T')[0];
      }
      if (toDate != null) {
        queryParams['completed_at__lte'] = toDate.toIso8601String().split('T')[0];
      }

      final response = await _api.getList(
        AppConstants.deliveryAssignmentsEndpoint,
        queryParams: queryParams,
      );

      if (response.isSuccess && response.data != null) {
        return response.data!
            .map((json) => DeliveryAssignment.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return [];
    } catch (e) {
      print('Error fetching completed deliveries: $e');
      return [];
    }
  }

  /// Fetch a single delivery assignment by ID
  Future<DeliveryAssignment?> getDeliveryById(int id) async {
    try {
      final response = await _api.get(
        '${AppConstants.deliveryAssignmentsEndpoint}$id/',
      );

      if (response.isSuccess && response.data != null) {
        return DeliveryAssignment.fromJson(response.data!);
      }
      return null;
    } catch (e) {
      print('Error fetching delivery $id: $e');
      return null;
    }
  }

  /// Accept a delivery assignment (changes status from assigned to accepted)
  Future<bool> acceptDelivery(int assignmentId) async {
    try {
      final response = await _api.post(
        '${AppConstants.completeDeliveryEndpoint}$assignmentId/accept/',
      );
      return response.isSuccess;
    } catch (e) {
      print('Error accepting delivery: $e');
      return false;
    }
  }

  /// Mark delivery as in transit (picked up and on the way)
  Future<bool> startDelivery(int assignmentId) async {
    try {
      final response = await _api.post(
        '${AppConstants.completeDeliveryEndpoint}$assignmentId/start/',
      );
      return response.isSuccess;
    } catch (e) {
      print('Error starting delivery: $e');
      return false;
    }
  }

  /// Complete a delivery with OTP verification and proof
  Future<DeliveryCompletionResponse> completeDelivery({
    required int assignmentId,
    required DeliveryProof proof,
  }) async {
    try {
      final endpoint = '${AppConstants.completeDeliveryEndpoint}$assignmentId/complete/';

      // If there's a proof image, use multipart upload
      if (proof.proofImagePath != null && proof.proofImagePath!.isNotEmpty) {
        final response = await _api.postMultipart(
          endpoint,
          fields: proof.toFormFields(),
          filePath: proof.proofImagePath!,
          fileFieldName: 'proof_image',
        );

        if (response.isSuccess) {
          return DeliveryCompletionResponse.fromJson(response.data ?? {});
        } else {
          return DeliveryCompletionResponse.error(response.error ?? 'Failed to complete delivery');
        }
      } else {
        // No image, use regular POST
        final response = await _api.post(
          endpoint,
          body: proof.toJson(),
        );

        if (response.isSuccess) {
          return DeliveryCompletionResponse.fromJson(response.data ?? {});
        } else {
          return DeliveryCompletionResponse.error(response.error ?? 'Failed to complete delivery');
        }
      }
    } catch (e) {
      print('Error completing delivery: $e');
      return DeliveryCompletionResponse.error(e.toString());
    }
  }

  /// Mark a delivery as failed
  Future<bool> failDelivery(int assignmentId, String reason) async {
    try {
      final response = await _api.post(
        '${AppConstants.completeDeliveryEndpoint}$assignmentId/fail/',
        body: {'reason': reason},
      );
      return response.isSuccess;
    } catch (e) {
      print('Error failing delivery: $e');
      return false;
    }
  }

  /// Update delivery location (for tracking)
  Future<bool> updateLocation(int assignmentId, double latitude, double longitude) async {
    try {
      final response = await _api.patch(
        '${AppConstants.completeDeliveryEndpoint}$assignmentId/location/',
        body: {
          'current_latitude': latitude,
          'current_longitude': longitude,
        },
      );
      return response.isSuccess;
    } catch (e) {
      print('Error updating location: $e');
      return false;
    }
  }

}
