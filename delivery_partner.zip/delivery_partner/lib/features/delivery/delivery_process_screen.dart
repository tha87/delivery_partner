import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import '../../core/app_theme.dart';
import '../../models/delivery_assignment_model.dart';
import '../../models/delivery_proof_model.dart';
import 'delivery_service.dart';

class DeliveryProcessScreen extends StatefulWidget {
  final DeliveryAssignment order;
  const DeliveryProcessScreen({super.key, required this.order});

  @override
  State<DeliveryProcessScreen> createState() => _DeliveryProcessScreenState();
}

class _DeliveryProcessScreenState extends State<DeliveryProcessScreen> {
  int _currentStep = 0;
  final _otpController = TextEditingController();
  final _imagePicker = ImagePicker();
  final _deliveryService = DeliveryService();
  
  XFile? _proofImage;
  bool _emptyCollected = true;
  bool _conditionGood = true;
  bool _isSubmitting = false;
  String? _errorMessage;
  DeliveryCompletionResponse? _completionResponse;
  
  // GPS location
  Position? _currentPosition;
  bool _locationLoading = false;

  final List<_StepData> _steps = [
    _StepData(icon: Icons.location_on_rounded, title: 'Reach Location'),
    _StepData(icon: Icons.pin_rounded, title: 'Verify OTP'),
    _StepData(icon: Icons.camera_alt_rounded, title: 'Upload Proof'),
    _StepData(icon: Icons.swap_horiz_rounded, title: 'Empty Cylinder'),
    _StepData(icon: Icons.check_circle_rounded, title: 'Complete'),
  ];

  @override
  void initState() {
    super.initState();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    setState(() => _locationLoading = true);
    
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _locationLoading = false;
          _errorMessage = 'Please enable GPS';
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            _locationLoading = false;
            _errorMessage = 'Location permission denied';
          });
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        setState(() {
          _locationLoading = false;
          _errorMessage = 'Location permission permanently denied';
        });
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      
      setState(() {
        _currentPosition = position;
        _locationLoading = false;
      });
    } catch (e) {
      setState(() {
        _locationLoading = false;
        _errorMessage = 'Failed to get location';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Order #${widget.order.bookingReference ?? widget.order.id}'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          // Step Indicator
          Container(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
            child: Row(
              children: List.generate(_steps.length, (index) {
                final isActive = index == _currentStep;
                final isCompleted = index < _currentStep;
                return Expanded(
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: isCompleted
                              ? AppTheme.success
                              : isActive
                                  ? AppTheme.primary
                                  : AppTheme.backgroundLight,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isActive ? AppTheme.primary : Colors.transparent,
                            width: 2,
                          ),
                        ),
                        child: Icon(
                          isCompleted ? Icons.check_rounded : _steps[index].icon,
                          color: isCompleted || isActive ? Colors.white : AppTheme.textSecondary,
                          size: 18,
                        ),
                      ),
                      if (index < _steps.length - 1)
                        Expanded(
                          child: Container(
                            height: 3,
                            color: isCompleted ? AppTheme.success : Colors.grey.shade200,
                          ),
                        ),
                    ],
                  ),
                );
              }),
            ),
          ),

          // Error message
          if (_errorMessage != null)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 24),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: AppTheme.error, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _errorMessage!,
                      style: TextStyle(color: AppTheme.error, fontSize: 13),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 18),
                    onPressed: () => setState(() => _errorMessage = null),
                    color: AppTheme.error,
                  ),
                ],
              ),
            ),

          // Step Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _steps[_currentStep].title,
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 24),
                  _buildStepContent(),
                ],
              ),
            ),
          ),

          // Action Buttons
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, -5),
                ),
              ],
            ),
            child: Row(
              children: [
                if (_currentStep > 0 && _currentStep < 4)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _isSubmitting ? null : () => setState(() => _currentStep--),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        side: const BorderSide(color: AppTheme.primary),
                      ),
                      child: const Text('Back'),
                    ),
                  ),
                if (_currentStep > 0 && _currentStep < 4) const SizedBox(width: 16),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _isSubmitting ? null : (_currentStep == 4 ? () => context.go('/') : _onNextStep),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      backgroundColor: _currentStep == 4 ? AppTheme.success : AppTheme.primary,
                    ),
                    child: _isSubmitting
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                          )
                        : Text(_currentStep == 4 ? 'Back to Dashboard' : 'Next Step'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildLocationStep();
      case 1:
        return _buildOtpStep();
      case 2:
        return _buildProofStep();
      case 3:
        return _buildEmptyStep();
      case 4:
        return _buildCompleteStep();
      default:
        return const SizedBox();
    }
  }

  Widget _buildLocationStep() {
    return Column(
      children: [
        // Customer Address
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: AppTheme.backgroundLight,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              const Icon(Icons.location_on_rounded, color: AppTheme.accent, size: 24),
              const SizedBox(width: 16),
              Expanded(child: Text(widget.order.displayAddress)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        
        // Customer Phone
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.backgroundLight,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.phone_rounded, color: AppTheme.primary),
              const SizedBox(width: 12),
              Text(widget.order.customerPhone, style: const TextStyle(fontWeight: FontWeight.w500)),
              const Spacer(),
              TextButton.icon(
                onPressed: () {
                  // Could add call functionality here
                },
                icon: const Icon(Icons.call, size: 18),
                label: const Text('Call'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        
        // Geo-fence verification info
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.withOpacity(0.3)),
          ),
          child: const Row(
            children: [
              Icon(Icons.radar_rounded, color: Colors.blue),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Geo-Fence Active', style: TextStyle(color: Colors.blue, fontWeight: FontWeight.w600)),
                    Text('Delivery can only be marked complete within 100m of address', style: TextStyle(color: Colors.blue, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        // GPS Status
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _locationLoading 
                ? Colors.orange.withOpacity(0.1)
                : _currentPosition != null 
                    ? AppTheme.success.withOpacity(0.1)
                    : AppTheme.error.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: _locationLoading 
                  ? Colors.orange.withOpacity(0.3)
                  : _currentPosition != null 
                      ? AppTheme.success.withOpacity(0.3)
                      : AppTheme.error.withOpacity(0.3),
            ),
          ),
          child: Row(
            children: [
              if (_locationLoading)
                const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.orange),
                )
              else
                Icon(
                  _currentPosition != null ? Icons.gps_fixed_rounded : Icons.gps_off_rounded,
                  color: _currentPosition != null ? AppTheme.success : AppTheme.error,
                ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _locationLoading 
                      ? 'Getting your location...'
                      : _currentPosition != null 
                          ? 'GPS Location Verified'
                          : 'GPS Location Required',
                  style: TextStyle(
                    color: _locationLoading 
                        ? Colors.orange
                        : _currentPosition != null 
                            ? AppTheme.success 
                            : AppTheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              if (_currentPosition == null && !_locationLoading)
                TextButton(
                  onPressed: _getCurrentLocation,
                  child: const Text('Retry'),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOtpStep() {
    return Column(
      children: [
        const Text('Enter the 4-digit OTP provided by the customer'),
        const SizedBox(height: 24),
        TextField(
          controller: _otpController,
          keyboardType: TextInputType.number,
          maxLength: 4,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 32, letterSpacing: 16, fontWeight: FontWeight.bold),
          decoration: InputDecoration(
            counterText: '',
            filled: true,
            fillColor: AppTheme.backgroundLight,
            hintText: '----',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text('Ask customer for their delivery OTP', style: TextStyle(color: AppTheme.textSecondary)),
      ],
    );
  }

  Widget _buildProofStep() {
    return Column(
      children: [
        const Text('Capture a photo of the delivered cylinder at customer location'),
        const SizedBox(height: 16),
        if (_proofImage != null)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.check_circle_rounded, color: AppTheme.success),
                const SizedBox(width: 12),
                Expanded(child: Text('Photo captured: ${_proofImage!.name}')),
                IconButton(
                  icon: const Icon(Icons.refresh, color: AppTheme.primary),
                  onPressed: _pickImage,
                ),
              ],
            ),
          )
        else
          GestureDetector(
            onTap: _pickImage,
            child: Container(
              height: 200,
              decoration: BoxDecoration(
                color: AppTheme.backgroundLight,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey.shade300, style: BorderStyle.solid),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.camera_alt_rounded, size: 48, color: AppTheme.primary),
                  SizedBox(height: 12),
                  Text('Tap to capture delivery photo'),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildEmptyStep() {
    return Column(
      children: [
        CheckboxListTile(
          value: _emptyCollected,
          onChanged: (val) => setState(() => _emptyCollected = val ?? false),
          title: const Text('Empty cylinder collected'),
          activeColor: AppTheme.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        CheckboxListTile(
          value: _conditionGood,
          onChanged: (val) => setState(() => _conditionGood = val ?? false),
          title: const Text('Cylinder in good condition'),
          activeColor: AppTheme.primary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        if (!_conditionGood) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.warning.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.warning_rounded, color: AppTheme.warning),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'Please report the cylinder damage to support',
                    style: TextStyle(color: AppTheme.warning),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildCompleteStep() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppTheme.success.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 80),
          ),
          const SizedBox(height: 24),
          Text('Delivery Complete!', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text(
            'Order #${widget.order.bookingReference ?? widget.order.id} has been delivered successfully.',
            style: TextStyle(color: AppTheme.textSecondary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          if (_completionResponse?.earningsAdded != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: AppTheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                'Earnings Added: ₹${_completionResponse!.earningsAdded!.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: AppTheme.primary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (_completionResponse?.newTotalDeliveries != null) ...[
            Text(
              'Total Deliveries: ${_completionResponse!.newTotalDeliveries}',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 12),
          ],
          if (widget.order.isCod && !widget.order.isPaid)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.payments_rounded, color: AppTheme.success),
                  const SizedBox(width: 12),
                  Text(
                    'Collected: ₹${widget.order.amount.toStringAsFixed(0)}',
                    style: const TextStyle(
                      color: AppTheme.success,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  void _onNextStep() async {
    setState(() => _errorMessage = null);

    // Step 0: Location verification
    if (_currentStep == 0) {
      if (_currentPosition == null) {
        setState(() => _errorMessage = 'Please wait for GPS location');
        return;
      }
      // Optionally verify geo-fence distance here
      setState(() => _currentStep++);
      return;
    }

    // Step 1: OTP verification
    if (_currentStep == 1) {
      if (_otpController.text.length != 4) {
        setState(() => _errorMessage = 'Please enter 4-digit OTP');
        return;
      }
      // OTP will be verified on final submission
      setState(() => _currentStep++);
      return;
    }

    // Step 2: Proof photo
    if (_currentStep == 2) {
      // Photo is optional but recommended
      setState(() => _currentStep++);
      return;
    }

    // Step 3: Submit to API
    if (_currentStep == 3) {
      await _submitDelivery();
      return;
    }
  }

  Future<void> _submitDelivery() async {
    setState(() {
      _isSubmitting = true;
      _errorMessage = null;
    });

    try {
      final proof = DeliveryProof(
        assignmentId: widget.order.id.toString(),
        otp: _otpController.text,
        proofImagePath: _proofImage?.path,
        latitude: _currentPosition?.latitude,
        longitude: _currentPosition?.longitude,
        emptyCylinderCollected: _emptyCollected,
        cylinderConditionGood: _conditionGood,
        amountCollected: widget.order.isCod ? widget.order.amount : null,
      );

      final response = await _deliveryService.completeDelivery(
        assignmentId: widget.order.id,
        proof: proof,
      );

      setState(() => _isSubmitting = false);

      if (response.success) {
        setState(() {
          _completionResponse = response;
          _currentStep = 4;
        });
      } else {
        setState(() => _errorMessage = response.message ?? 'Failed to complete delivery');
      }
    } catch (e) {
      setState(() {
        _isSubmitting = false;
        _errorMessage = e.toString();
      });
    }
  }

  Future<void> _pickImage() async {
    final XFile? image = await _imagePicker.pickImage(
      source: ImageSource.camera,
      imageQuality: 80,
    );
    if (image != null) {
      setState(() => _proofImage = image);
    }
  }
}

class _StepData {
  final IconData icon;
  final String title;
  _StepData({required this.icon, required this.title});
}
