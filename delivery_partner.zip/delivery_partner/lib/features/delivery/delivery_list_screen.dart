import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/app_theme.dart';
import 'delivery_service.dart';
import '../../models/delivery_assignment_model.dart';

class DeliveryListScreen extends StatefulWidget {
  const DeliveryListScreen({super.key});

  @override
  State<DeliveryListScreen> createState() => _DeliveryListScreenState();
}

class _DeliveryListScreenState extends State<DeliveryListScreen> with SingleTickerProviderStateMixin {
  final DeliveryService _deliveryService = DeliveryService();
  late TabController _tabController;
  
  List<DeliveryAssignment> _assignedOrders = [];
  List<DeliveryAssignment> _pendingOrders = [];
  List<DeliveryAssignment> _completedOrders = [];
  
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadDeliveries();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadDeliveries() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Try API first, fallback to mock data
      final assigned = await _deliveryService.getAssignedDeliveries();
      final pending = await _deliveryService.getPendingDeliveries();
      final completed = await _deliveryService.getCompletedDeliveries();

      setState(() {
        _assignedOrders = assigned.isNotEmpty ? assigned : _deliveryService.getMockAssignedOrders();
        _pendingOrders = pending.isNotEmpty ? pending : _assignedOrders.where((o) => o.isPending).toList();
        _completedOrders = completed;
        _isLoading = false;
      });
    } catch (e) {
      // Fallback to mock data on error
      setState(() {
        _assignedOrders = _deliveryService.getMockAssignedOrders();
        _pendingOrders = _assignedOrders.where((o) => o.isPending).toList();
        _completedOrders = [];
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Deliveries'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textSecondary,
          tabs: [
            Tab(text: 'Assigned (${_assignedOrders.length})'),
            Tab(text: 'Pending (${_pendingOrders.length})'),
            Tab(text: 'Completed (${_completedOrders.length})'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 48, color: AppTheme.error),
                      const SizedBox(height: 16),
                      Text(_error!, style: TextStyle(color: AppTheme.textSecondary)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadDeliveries,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadDeliveries,
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildOrderList(_assignedOrders, 'No assigned deliveries'),
                      _buildOrderList(_pendingOrders, 'No pending deliveries'),
                      _buildOrderList(_completedOrders, 'No completed deliveries'),
                    ],
                  ),
                ),
    );
  }

  Widget _buildOrderList(List<DeliveryAssignment> orders, String emptyMessage) {
    if (orders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.5)),
            const SizedBox(height: 16),
            Text(emptyMessage, style: TextStyle(color: AppTheme.textSecondary)),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: orders.length,
      padding: const EdgeInsets.all(20),
      itemBuilder: (context, index) {
        final order = orders[index];
        return _OrderCard(order: order, onRefresh: _loadDeliveries);
      },
    );
  }
}

class _OrderCard extends StatelessWidget {
  final DeliveryAssignment order;
  final VoidCallback? onRefresh;
  
  const _OrderCard({required this.order, this.onRefresh});

  Color _getStatusColor(DeliveryAssignmentStatus status) {
    switch (status) {
      case DeliveryAssignmentStatus.assigned:
        return AppTheme.primary;
      case DeliveryAssignmentStatus.accepted:
        return Colors.orange;
      case DeliveryAssignmentStatus.inTransit:
        return Colors.blue;
      case DeliveryAssignmentStatus.completed:
        return AppTheme.success;
      case DeliveryAssignmentStatus.failed:
        return AppTheme.error;
      case DeliveryAssignmentStatus.cancelled:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(order.status);
    
    return GestureDetector(
      onTap: () => context.push('/delivery/details/${order.id}', extra: order),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade100),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.08),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.person_rounded, color: AppTheme.primary, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order.customerName,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          'Order #${order.bookingReference ?? order.id}',
                          style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    order.status.displayName,
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            const Divider(height: 1),
            const SizedBox(height: 16),
            
            // Order Details
            Row(
              children: [
                _buildDetailChip(Icons.local_gas_station_rounded, order.cylinderInfo),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.location_on_outlined, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    order.displayAddress,
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            
            // Phone number
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.phone_outlined, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 6),
                Text(
                  order.customerPhone,
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Payment Row
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: order.isCod 
                    ? (order.isPaid ? AppTheme.success.withOpacity(0.1) : AppTheme.warning.withOpacity(0.1))
                    : AppTheme.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        order.isCod 
                            ? (order.isPaid ? Icons.verified_rounded : Icons.payments_rounded)
                            : Icons.verified_rounded,
                        color: order.isCod 
                            ? (order.isPaid ? AppTheme.success : AppTheme.warning)
                            : AppTheme.success,
                        size: 18,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        order.isCod 
                            ? (order.isPaid ? 'COD Collected' : 'Cash on Delivery')
                            : 'Paid Online',
                        style: TextStyle(
                          color: order.isCod 
                              ? (order.isPaid ? AppTheme.success : AppTheme.warning)
                              : AppTheme.success,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    '₹${order.amount.toStringAsFixed(0)}',
                    style: TextStyle(
                      color: order.isCod 
                          ? (order.isPaid ? AppTheme.success : AppTheme.warning)
                          : AppTheme.success,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.backgroundLight,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppTheme.textSecondary),
          const SizedBox(width: 6),
          Text(text, style: TextStyle(fontSize: 12, color: AppTheme.textPrimary)),
        ],
      ),
    );
  }
}
