import '../../core/api_service.dart';
import '../../models/delivery_assignment_model.dart';
import '../../core/constants.dart';

class DeliveryRepository {
  final ApiService _apiService = ApiService();

  /// Fetch all assigned orders (Status: ASSIGNED)
  Future<List<DeliveryAssignment>> getAssignedOrders() async {
    try {
      final response = await _apiService.get(
        '${AppConstants.deliveryAssignmentsEndpoint}assigned/', 
        requiresAuth: true
      );

      if (response.isSuccess && response.data != null) {
        final List<dynamic> data = response.data!;
        return data.map((json) => DeliveryAssignment.fromJson(json)).toList();
      } else {
        throw Exception(response.error ?? 'Failed to load assigned orders');
      }
    } catch (e) {
      rethrow;
    }
  }

  /// Accept an assignment (ASSIGNED -> PENDING)
  Future<void> acceptAssignment(String assignmentId) async {
    try {
      final response = await _apiService.post(
        '${AppConstants.deliveryAssignmentsEndpoint}$assignmentId/accept/',
        requiresAuth: true
      );

      if (!response.isSuccess) {
        throw Exception(response.error ?? 'Failed to accept assignment');
      }
    } catch (e) {
      rethrow;
    }
  }
}
