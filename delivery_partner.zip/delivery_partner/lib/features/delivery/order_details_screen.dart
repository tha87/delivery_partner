import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/app_theme.dart';
import '../../models/delivery_assignment_model.dart';
import 'delivery_service.dart';

class OrderDetailsScreen extends StatelessWidget {
  final DeliveryAssignment order;

  const OrderDetailsScreen({super.key, required this.order});

  Future<void> _makePhoneCall() async {
    final Uri launchUri = Uri(scheme: 'tel', path: order.customerPhone);
    await launchUrl(launchUri);
  }

  @override
  Widget build(BuildContext context) {
    // Use address coordinates if available, otherwise default to Bangalore
    final lat = order.address?.latitude ?? 12.9716;
    final lng = order.address?.longitude ?? 77.5946;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar with Map
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_rounded, size: 18),
                  onPressed: () => context.pop(),
                ),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(lat, lng),
                  zoom: 14,
                ),
                markers: {
                  Marker(
                    markerId: const MarkerId('delivery_loc'),
                    position: LatLng(lat, lng),
                    infoWindow: InfoWindow(title: order.customerName),
                  ),
                },
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
              ),
            ),
          ),
          
          // Content
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Order ID & Status
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Order #${order.bookingReference ?? order.id}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getStatusColor(order.status).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            order.status.displayName,
                            style: TextStyle(
                              color: _getStatusColor(order.status),
                              fontWeight: FontWeight.w600,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Customer Card
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.backgroundLight,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.person_rounded, color: AppTheme.primary),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  order.customerName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 18,
                                  ),
                                ),
                                Text(
                                  _maskPhone(order.customerPhone),
                                  style: TextStyle(color: AppTheme.textSecondary),
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: _makePhoneCall,
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppTheme.success.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.call_rounded, color: AppTheme.success),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Section Title
                    Text('Delivery Address', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade200),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.location_on_rounded, color: AppTheme.accent),
                          const SizedBox(width: 12),
                          Expanded(child: Text(order.displayAddress)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Order Info
                    Text('Order Details', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 12),
                    _buildInfoRow('Cylinder Type', order.cylinderType ?? 'N/A'),
                    _buildInfoRow('Quantity', '${order.quantity}'),
                    if (order.scheduledDate != null)
                      _buildInfoRow('Scheduled Date', _formatDate(order.scheduledDate!)),
                    if (order.scheduledTimeSlot != null)
                      _buildInfoRow('Time Slot', order.scheduledTimeSlot!),
                    if (order.specialInstructions != null && order.specialInstructions!.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.info_outline, color: Colors.blue, size: 20),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                order.specialInstructions!,
                                style: const TextStyle(color: Colors.blue, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    
                    const SizedBox(height: 24),
                    
                    // Payment Card
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: order.isCod
                            ? (order.isPaid 
                                ? LinearGradient(colors: [AppTheme.success.withOpacity(0.8), AppTheme.success])
                                : LinearGradient(colors: [AppTheme.warning.withOpacity(0.8), AppTheme.warning]))
                            : LinearGradient(colors: [AppTheme.success.withOpacity(0.8), AppTheme.success]),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                order.isCod 
                                    ? (order.isPaid ? 'COD Collected' : 'Cash on Delivery')
                                    : 'Paid Online',
                                style: const TextStyle(color: Colors.white70, fontSize: 14),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '₹${order.amount.toStringAsFixed(0)}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          Icon(
                            order.isCod 
                                ? (order.isPaid ? Icons.verified_rounded : Icons.payments_rounded)
                                : Icons.verified_rounded,
                            color: Colors.white,
                            size: 40,
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Action Button (only show if not completed)
                      if (!order.isCompleted)
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: SizedBox(
                            width: double.infinity,
                            height: 56,
                            child: ElevatedButton(
                              onPressed: () => _startDelivery(context),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.primary,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.local_shipping_rounded),
                                  SizedBox(width: 8),
                                  Text(
                                    'Start Delivery',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }
  
  Future<void> _startDelivery(BuildContext context) async {
    // Show loading
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => const Center(child: CircularProgressIndicator()),
    );

    final service = DeliveryService();
    final success = await service.startDelivery(order.id);

    // Hide loading
    if (context.mounted) {
      Navigator.pop(context);
    }

    if (success) {
      if (context.mounted) {
        context.push('/delivery/process/${order.id}', extra: order);
      }
    } else {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to start delivery. Please try again.'),
            backgroundColor: AppTheme.error,
          ),
        );
      }
    }
  }

  Color _getStatusColor(DeliveryAssignmentStatus status) {
    switch (status) {
      case DeliveryAssignmentStatus.assigned:
        return AppTheme.primary;
      case DeliveryAssignmentStatus.accepted:
        return Colors.orange;
      case DeliveryAssignmentStatus.inTransit:
        return Colors.blue;
      case DeliveryAssignmentStatus.completed:
        return AppTheme.success;
      case DeliveryAssignmentStatus.failed:
        return AppTheme.error;
      case DeliveryAssignmentStatus.cancelled:
        return Colors.grey;
    }
  }

  String _maskPhone(String phone) {
    if (phone.length >= 8) {
      return phone.replaceRange(4, phone.length - 2, '****');
    }
    return phone;
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: AppTheme.textSecondary)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
