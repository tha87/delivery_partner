import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import '../../models/delivery_history_model.dart';

class HistoryDetailScreen extends StatelessWidget {
  final DeliveryHistory history;
  const HistoryDetailScreen({super.key, required this.history});

  Color _getStatusColor() {
    switch (history.status) {
      case DeliveryStatus.delivered:
        return AppTheme.success;
      case DeliveryStatus.failed:
        return AppTheme.error;
      case DeliveryStatus.returned:
        return AppTheme.warning;
    }
  }

  String _getStatusText() {
    switch (history.status) {
      case DeliveryStatus.delivered:
        return 'Delivered';
      case DeliveryStatus.failed:
        return 'Failed';
      case DeliveryStatus.returned:
        return 'Returned';
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

    return Scaffold(
      appBar: AppBar(
        title: Text(history.orderId),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _getStatusColor().withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _getStatusColor(),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      history.status == DeliveryStatus.delivered
                          ? Icons.check_rounded
                          : history.status == DeliveryStatus.failed
                              ? Icons.close_rounded
                              : Icons.refresh_rounded,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_getStatusText(), style: TextStyle(color: _getStatusColor(), fontSize: 20, fontWeight: FontWeight.bold)),
                      Text(dateFormat.format(history.deliveryDateTime), style: TextStyle(color: _getStatusColor().withOpacity(0.8))),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Order Info Section
            _buildSectionTitle(context, 'Order Information'),
            const SizedBox(height: 12),
            _buildInfoCard([
              _buildInfoRow('Order ID', history.orderId),
              _buildInfoRow('Customer', history.customerName),
              _buildInfoRow('Phone', history.phone.replaceRange(4, 8, '****')),
              _buildInfoRow('Address', history.address),
              _buildInfoRow('Cylinder', '${history.quantity}x ${history.cylinderType}'),
            ]),

            const SizedBox(height: 24),

            // Proof of Delivery Section
            if (history.status == DeliveryStatus.delivered) ...[
              _buildSectionTitle(context, 'Proof of Delivery'),
              const SizedBox(height: 12),
              _buildInfoCard([
                _buildInfoRow('OTP Used', history.otpUsed?.replaceRange(1, 3, '**') ?? 'N/A'),
                _buildInfoRow('Photos', '${history.deliveryPhotos.length} captured'),
                if (history.latitude != null && history.longitude != null)
                  _buildInfoRow('GPS Location', '${history.latitude!.toStringAsFixed(4)}, ${history.longitude!.toStringAsFixed(4)}'),
                _buildInfoRow('Timestamp', dateFormat.format(history.deliveryDateTime)),
              ]),
              const SizedBox(height: 24),
            ],

            // Cylinder Return Section
            _buildSectionTitle(context, 'Cylinder Return'),
            const SizedBox(height: 12),
            _buildInfoCard([
              _buildStatusRow('Empty Collected', history.emptyCylinderCollected),
              _buildStatusRow('Condition Good', history.cylinderConditionGood),
              if (history.damagePhotoUrl != null)
                _buildInfoRow('Damage Photo', 'Captured'),
            ]),

            const SizedBox(height: 24),

            // Payment Info Section
            _buildSectionTitle(context, 'Payment Information'),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: history.isCod
                    ? LinearGradient(colors: [AppTheme.warning.withOpacity(0.8), AppTheme.warning])
                    : LinearGradient(colors: [AppTheme.success.withOpacity(0.8), AppTheme.success]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(history.isCod ? 'Cash on Delivery' : 'Paid Online', style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 4),
                      Text('₹${history.amount.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                      if (history.isCod && history.amountCollected != null)
                        Text('Collected: ₹${history.amountCollected!.toStringAsFixed(0)}', style: const TextStyle(color: Colors.white70)),
                    ],
                  ),
                  Icon(history.isCod ? Icons.payments_rounded : Icons.verified_rounded, color: Colors.white, size: 40),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Rating Section
            if (history.rating != null) ...[
              _buildSectionTitle(context, 'Customer Rating'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return Icon(
                      index < history.rating! ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: AppTheme.warning,
                      size: 32,
                    );
                  }),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Text(title, style: Theme.of(context).textTheme.titleLarge);
  }

  Widget _buildInfoCard(List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(children: children),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: AppTheme.textSecondary)),
          const SizedBox(width: 16),
          Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600), textAlign: TextAlign.end)),
        ],
      ),
    );
  }

  Widget _buildStatusRow(String label, bool value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: AppTheme.textSecondary)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: value ? AppTheme.success.withOpacity(0.1) : AppTheme.error.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(value ? Icons.check_circle_rounded : Icons.cancel_rounded, size: 14, color: value ? AppTheme.success : AppTheme.error),
                const SizedBox(width: 4),
                Text(value ? 'Yes' : 'No', style: TextStyle(color: value ? AppTheme.success : AppTheme.error, fontSize: 12, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
