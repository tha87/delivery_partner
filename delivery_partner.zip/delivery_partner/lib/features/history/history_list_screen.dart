import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import '../../models/delivery_history_model.dart';
import 'history_service.dart';

class HistoryListScreen extends StatefulWidget {
  const HistoryListScreen({super.key});

  @override
  State<HistoryListScreen> createState() => _HistoryListScreenState();
}

class _HistoryListScreenState extends State<HistoryListScreen> {
  final HistoryService _historyService = HistoryService();
  final TextEditingController _searchController = TextEditingController();
  
  String _selectedFilter = 'All';
  List<DeliveryHistory> _allHistory = [];
  List<DeliveryHistory> _filteredHistory = [];

  final List<String> _filters = ['All', 'Today', 'Last 7 days', 'Last 30 days'];

  @override
  void initState() {
    super.initState();
    _allHistory = _historyService.getDeliveryHistory();
    _filteredHistory = _allHistory;
  }

  void _applyFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);

      switch (filter) {
        case 'Today':
          _filteredHistory = _allHistory.where((h) {
            final deliveryDate = DateTime(h.deliveryDateTime.year, h.deliveryDateTime.month, h.deliveryDateTime.day);
            return deliveryDate == today;
          }).toList();
          break;
        case 'Last 7 days':
          _filteredHistory = _allHistory.where((h) => h.deliveryDateTime.isAfter(now.subtract(const Duration(days: 7)))).toList();
          break;
        case 'Last 30 days':
          _filteredHistory = _allHistory.where((h) => h.deliveryDateTime.isAfter(now.subtract(const Duration(days: 30)))).toList();
          break;
        default:
          _filteredHistory = _allHistory;
      }
      _applySearch(_searchController.text);
    });
  }

  void _applySearch(String query) {
    if (query.isEmpty) {
      _applyFilter(_selectedFilter);
      return;
    }
    setState(() {
      _filteredHistory = _filteredHistory.where((h) =>
        h.orderId.toLowerCase().contains(query.toLowerCase()) ||
        h.customerName.toLowerCase().contains(query.toLowerCase()) ||
        h.area.toLowerCase().contains(query.toLowerCase())
      ).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final summary = _historyService.getEarningsSummary();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Delivery History'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          // Summary Cards
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                _buildSummaryChip(Icons.check_circle_rounded, '${summary['totalDeliveries']}', 'Delivered', AppTheme.success),
                const SizedBox(width: 8),
                _buildSummaryChip(Icons.cancel_rounded, '${summary['failedDeliveries']}', 'Failed', AppTheme.error),
                const SizedBox(width: 8),
                _buildSummaryChip(Icons.refresh_rounded, '${summary['returnedDeliveries']}', 'Returned', AppTheme.warning),
              ],
            ),
          ),

          // Search Bar
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: _searchController,
              onChanged: _applySearch,
              decoration: InputDecoration(
                hintText: 'Search by Order ID, Name, Area...',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: AppTheme.backgroundLight,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // Filter Chips
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = filter == _selectedFilter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (_) => _applyFilter(filter),
                    backgroundColor: Colors.white,
                    selectedColor: AppTheme.primary.withOpacity(0.1),
                    labelStyle: TextStyle(
                      color: isSelected ? AppTheme.primary : AppTheme.textSecondary,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    ),
                    side: BorderSide(color: isSelected ? AppTheme.primary : Colors.grey.shade300),
                  ),
                );
              },
            ),
          ),

          // List
          Expanded(
            child: _filteredHistory.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.history_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.5)),
                        const SizedBox(height: 16),
                        Text('No deliveries found', style: TextStyle(color: AppTheme.textSecondary)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredHistory.length,
                    itemBuilder: (context, index) {
                      final history = _filteredHistory[index];
                      return _HistoryCard(history: history);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryChip(IconData icon, String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 6),
            Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(color: color, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}

class _HistoryCard extends StatelessWidget {
  final DeliveryHistory history;
  const _HistoryCard({required this.history});

  Color _getStatusColor() {
    switch (history.status) {
      case DeliveryStatus.delivered:
        return AppTheme.success;
      case DeliveryStatus.failed:
        return AppTheme.error;
      case DeliveryStatus.returned:
        return AppTheme.warning;
    }
  }

  IconData _getStatusIcon() {
    switch (history.status) {
      case DeliveryStatus.delivered:
        return Icons.check_circle_rounded;
      case DeliveryStatus.failed:
        return Icons.cancel_rounded;
      case DeliveryStatus.returned:
        return Icons.refresh_rounded;
    }
  }

  String _getStatusText() {
    switch (history.status) {
      case DeliveryStatus.delivered:
        return 'Delivered';
      case DeliveryStatus.failed:
        return 'Failed';
      case DeliveryStatus.returned:
        return 'Returned';
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM, hh:mm a');

    return GestureDetector(
      onTap: () => context.push('/history/detail/${history.id}', extra: history),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade100),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(history.orderId, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getStatusColor().withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(_getStatusIcon(), size: 14, color: _getStatusColor()),
                      const SizedBox(width: 4),
                      Text(_getStatusText(), style: TextStyle(color: _getStatusColor(), fontSize: 12, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            
            // Customer Info
            Row(
              children: [
                const Icon(Icons.person_outline_rounded, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 6),
                Text(history.customerName, style: TextStyle(color: AppTheme.textPrimary)),
                const Spacer(),
                Icon(Icons.location_on_outlined, size: 16, color: AppTheme.textSecondary),
                const SizedBox(width: 4),
                Text(history.area, style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              ],
            ),
            const SizedBox(height: 8),
            
            // Details Row
            Row(
              children: [
                Icon(Icons.access_time_rounded, size: 14, color: AppTheme.textSecondary),
                const SizedBox(width: 4),
                Text(dateFormat.format(history.deliveryDateTime), style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                const Spacer(),
                Text('${history.quantity}x ${history.cylinderType}', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
