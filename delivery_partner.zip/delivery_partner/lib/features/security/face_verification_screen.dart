import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/app_theme.dart';
import 'face_verification_service.dart';

class FaceVerificationScreen extends StatefulWidget {
  final VerificationType verificationType;
  const FaceVerificationScreen({super.key, required this.verificationType});

  @override
  State<FaceVerificationScreen> createState() => _FaceVerificationScreenState();
}

class _FaceVerificationScreenState extends State<FaceVerificationScreen> {
  final FaceVerificationService _service = FaceVerificationService();
  bool _isProcessing = false;
  bool? _verificationResult;
  String _statusMessage = 'Position your face in the circle';

  Future<void> _startVerification() async {
    setState(() {
      _isProcessing = true;
      _statusMessage = 'Capturing selfie...';
    });

    final selfie = await _service.captureSelfie();
    
    if (selfie == null) {
      setState(() {
        _isProcessing = false;
        _statusMessage = 'Failed to capture. Try again.';
        _verificationResult = false;
      });
      return;
    }

    setState(() => _statusMessage = 'Verifying identity...');

    final success = await _service.verifyFace(widget.verificationType);

    setState(() {
      _isProcessing = false;
      _verificationResult = success;
      _statusMessage = success ? 'Verification successful!' : 'Verification failed. Try again.';
    });

    if (success) {
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) context.pop(true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundDark,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text(
          widget.verificationType == VerificationType.shiftStart 
            ? 'Start Shift Verification' 
            : 'Identity Check',
          style: const TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.close, color: Colors.white),
          onPressed: () => context.pop(false),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            const Spacer(),
            
            // Face Circle
            Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: _verificationResult == null
                      ? AppTheme.primary
                      : _verificationResult!
                          ? AppTheme.success
                          : AppTheme.error,
                  width: 4,
                ),
              ),
              child: _isProcessing
                  ? const Center(
                      child: CircularProgressIndicator(color: AppTheme.primary),
                    )
                  : Icon(
                      _verificationResult == null
                          ? Icons.face_rounded
                          : _verificationResult!
                              ? Icons.check_circle_rounded
                              : Icons.error_rounded,
                      size: 100,
                      color: _verificationResult == null
                          ? Colors.white54
                          : _verificationResult!
                              ? AppTheme.success
                              : AppTheme.error,
                    ),
            ),
            
            const SizedBox(height: 32),
            
            // Status Message
            Text(
              _statusMessage,
              style: const TextStyle(color: Colors.white, fontSize: 18),
              textAlign: TextAlign.center,
            ),
            
            const SizedBox(height: 16),
            
            // Instructions
            if (!_isProcessing && _verificationResult == null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  widget.verificationType == VerificationType.shiftStart
                      ? 'Take a selfie to verify your identity and start your shift'
                      : 'Random identity check. Please verify to continue deliveries.',
                  style: const TextStyle(color: Colors.white54, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ),
            
            const Spacer(),
            
            // Action Button
            if (!_isProcessing)
              Padding(
                padding: const EdgeInsets.all(24),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: ElevatedButton.icon(
                    onPressed: _verificationResult == true ? null : _startVerification,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                    ),
                    icon: const Icon(Icons.camera_alt_rounded),
                    label: Text(_verificationResult == false ? 'Try Again' : 'Capture Selfie'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
