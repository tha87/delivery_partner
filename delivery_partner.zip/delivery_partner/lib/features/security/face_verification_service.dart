import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

enum VerificationType { shiftStart, randomCheck }

class FaceVerificationService extends ChangeNotifier {
  final ImagePicker _picker = ImagePicker();
  
  bool _isVerified = false;
  bool _shiftStarted = false;
  DateTime? _lastVerification;
  XFile? _lastSelfie;

  bool get isVerified => _isVerified;
  bool get shiftStarted => _shiftStarted;
  DateTime? get lastVerification => _lastVerification;

  // Check if random verification is needed (every 2 hours during shift)
  bool needsRandomCheck() {
    if (!_shiftStarted || _lastVerification == null) return false;
    final hoursSinceLastCheck = DateTime.now().difference(_lastVerification!).inHours;
    // Random check needed after 2 hours with 30% probability
    return hoursSinceLastCheck >= 2 && Random().nextDouble() < 0.3;
  }

  Future<XFile?> captureSelfie() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 80,
      );
      if (image != null) {
        _lastSelfie = image;
      }
      return image;
    } catch (e) {
      return null;
    }
  }

  Future<bool> verifyFace(VerificationType type) async {
    final selfie = await captureSelfie();
    if (selfie == null) return false;

    // Mock face verification - in production, this would call an API
    await Future.delayed(const Duration(seconds: 2));
    
    // Simulate 95% success rate
    final success = Random().nextDouble() < 0.95;
    
    if (success) {
      _isVerified = true;
      _lastVerification = DateTime.now();
      if (type == VerificationType.shiftStart) {
        _shiftStarted = true;
      }
      notifyListeners();
    }
    
    return success;
  }

  void endShift() {
    _shiftStarted = false;
    _isVerified = false;
    _lastVerification = null;
    notifyListeners();
  }
}
