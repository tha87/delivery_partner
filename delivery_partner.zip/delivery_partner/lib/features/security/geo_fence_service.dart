import 'dart:math';
import 'package:geolocator/geolocator.dart';

class GeoFenceService {
  // Allowed radius in meters for delivery completion
  static const double allowedRadiusMeters = 100.0;

  // Check if current location is within allowed radius of target
  Future<GeoFenceResult> checkProximity({
    required double targetLat,
    required double targetLng,
  }) async {
    try {
      // Check location permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return GeoFenceResult(
            isWithinFence: false,
            error: 'Location permission denied',
          );
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return GeoFenceResult(
          isWithinFence: false,
          error: 'Location permission permanently denied. Enable in settings.',
        );
      }

      // Get current position
      final Position currentPosition = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      // Calculate distance
      final double distanceMeters = Geolocator.distanceBetween(
        currentPosition.latitude,
        currentPosition.longitude,
        targetLat,
        targetLng,
      );

      return GeoFenceResult(
        isWithinFence: distanceMeters <= allowedRadiusMeters,
        distanceMeters: distanceMeters,
        currentLat: currentPosition.latitude,
        currentLng: currentPosition.longitude,
      );
    } catch (e) {
      return GeoFenceResult(
        isWithinFence: false,
        error: 'Failed to get location: $e',
      );
    }
  }

  // Mock location check for demo (always succeeds with random distance)
  Future<GeoFenceResult> checkProximityMock({
    required double targetLat,
    required double targetLng,
  }) async {
    await Future.delayed(const Duration(seconds: 1));
    
    // 80% chance of being within fence for demo
    final bool withinFence = Random().nextDouble() < 0.8;
    final double mockDistance = withinFence 
        ? Random().nextDouble() * 80 // 0-80 meters
        : 100 + Random().nextDouble() * 500; // 100-600 meters

    return GeoFenceResult(
      isWithinFence: withinFence,
      distanceMeters: mockDistance,
      currentLat: targetLat + (Random().nextDouble() - 0.5) * 0.001,
      currentLng: targetLng + (Random().nextDouble() - 0.5) * 0.001,
    );
  }
}

class GeoFenceResult {
  final bool isWithinFence;
  final double? distanceMeters;
  final double? currentLat;
  final double? currentLng;
  final String? error;

  GeoFenceResult({
    required this.isWithinFence,
    this.distanceMeters,
    this.currentLat,
    this.currentLng,
    this.error,
  });

  String get distanceString {
    if (distanceMeters == null) return 'Unknown';
    if (distanceMeters! < 1000) {
      return '${distanceMeters!.toStringAsFixed(0)}m away';
    }
    return '${(distanceMeters! / 1000).toStringAsFixed(1)}km away';
  }
}
