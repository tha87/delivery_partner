import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import 'wallet_service.dart';

class WithdrawalHistoryScreen extends StatefulWidget {
  const WithdrawalHistoryScreen({super.key});

  @override
  State<WithdrawalHistoryScreen> createState() => _WithdrawalHistoryScreenState();
}

class _WithdrawalHistoryScreenState extends State<WithdrawalHistoryScreen> {
  final WalletService _service = WalletService();
  String _selectedFilter = 'All';
  late List<WithdrawalRecord> _allRecords;
  late List<WithdrawalRecord> _filteredRecords;

  final List<String> _filters = ['All', 'Last 7 days', 'Last 30 days'];

  @override
  void initState() {
    super.initState();
    _allRecords = _service.getWithdrawalHistory();
    _filteredRecords = _allRecords;
  }

  void _applyFilter(String filter) {
    setState(() {
      _selectedFilter = filter;
      final now = DateTime.now();

      switch (filter) {
        case 'Last 7 days':
          _filteredRecords = _allRecords.where((r) => r.dateTime.isAfter(now.subtract(const Duration(days: 7)))).toList();
          break;
        case 'Last 30 days':
          _filteredRecords = _allRecords.where((r) => r.dateTime.isAfter(now.subtract(const Duration(days: 30)))).toList();
          break;
        default:
          _filteredRecords = _allRecords;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Withdrawal History'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          // Filter Chips
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = filter == _selectedFilter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (_) => _applyFilter(filter),
                    backgroundColor: Colors.white,
                    selectedColor: AppTheme.primary.withOpacity(0.1),
                    labelStyle: TextStyle(
                      color: isSelected ? AppTheme.primary : AppTheme.textSecondary,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    ),
                    side: BorderSide(color: isSelected ? AppTheme.primary : Colors.grey.shade300),
                  ),
                );
              },
            ),
          ),

          // List
          Expanded(
            child: _filteredRecords.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.receipt_long_rounded, size: 64, color: AppTheme.textSecondary.withOpacity(0.5)),
                        const SizedBox(height: 16),
                        Text('No withdrawals found', style: TextStyle(color: AppTheme.textSecondary)),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _filteredRecords.length,
                    itemBuilder: (context, index) {
                      final record = _filteredRecords[index];
                      return _WithdrawalCard(record: record);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _WithdrawalCard extends StatelessWidget {
  final WithdrawalRecord record;
  const _WithdrawalCard({required this.record});

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd MMM, hh:mm a');
    
    Color statusColor;
    IconData statusIcon;
    String statusText;

    switch (record.status) {
      case WithdrawalStatus.pending:
        statusColor = AppTheme.warning;
        statusIcon = Icons.schedule_rounded;
        statusText = 'Pending';
        break;
      case WithdrawalStatus.processing:
        statusColor = Colors.blue;
        statusIcon = Icons.sync_rounded;
        statusText = 'Processing';
        break;
      case WithdrawalStatus.success:
        statusColor = AppTheme.success;
        statusIcon = Icons.check_circle_rounded;
        statusText = 'Success';
        break;
      case WithdrawalStatus.failed:
        statusColor = AppTheme.error;
        statusIcon = Icons.cancel_rounded;
        statusText = 'Failed';
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100),
        boxShadow: [
          BoxShadow(color: Colors.grey.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(record.id, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(statusIcon, size: 14, color: statusColor),
                    const SizedBox(width: 4),
                    Text(statusText, style: TextStyle(color: statusColor, fontSize: 12, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Details
          Row(
            children: [
              Icon(Icons.access_time_rounded, size: 14, color: AppTheme.textSecondary),
              const SizedBox(width: 4),
              Text(dateFormat.format(record.dateTime), style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
              const Spacer(),
              Icon(
                record.method == PayoutMethod.upi ? Icons.phone_android_rounded : Icons.account_balance_rounded,
                size: 14,
                color: AppTheme.textSecondary,
              ),
              const SizedBox(width: 4),
              Text(record.payoutTo, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            ],
          ),
          
          const SizedBox(height: 12),
          
          // Amount
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Amount'),
              Text('₹${record.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            ],
          ),

          // Failure Reason
          if (record.status == WithdrawalStatus.failed && record.failureReason != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.error.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.error_outline_rounded, color: AppTheme.error, size: 16),
                  const SizedBox(width: 8),
                  Expanded(child: Text(record.failureReason!, style: const TextStyle(color: AppTheme.error, fontSize: 12))),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
