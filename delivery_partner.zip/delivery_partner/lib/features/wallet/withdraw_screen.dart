import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../core/app_theme.dart';
import 'wallet_service.dart';

class WithdrawScreen extends StatefulWidget {
  const WithdrawScreen({super.key});

  @override
  State<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends State<WithdrawScreen> {
  final WalletService _service = WalletService();
  final _amountController = TextEditingController();
  final _upiController = TextEditingController();
  final _pinController = TextEditingController();
  
  late WalletData _walletData;
  int _currentStep = 0;
  PayoutMethod _selectedMethod = PayoutMethod.upi;
  bool _isProcessing = false;
  String? _upiError;

  @override
  void initState() {
    super.initState();
    _walletData = _service.getWalletData();
    if (_walletData.savedMethods.isNotEmpty) {
      _upiController.text = _walletData.savedMethods.first.value;
    }
  }

  double get _enteredAmount => double.tryParse(_amountController.text) ?? 0;
  double get _processingFee => _enteredAmount * WalletService.processingFeePercent;
  double get _netAmount => _enteredAmount - _processingFee;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Withdraw'),
        leading: IconButton(
          icon: const Icon(Icons.close_rounded),
          onPressed: () => context.pop(),
        ),
      ),
      body: Column(
        children: [
          // Progress Indicator
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: List.generate(4, (index) {
                final isActive = index == _currentStep;
                final isCompleted = index < _currentStep;
                return Expanded(
                  child: Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: isCompleted ? AppTheme.success : isActive ? AppTheme.primary : Colors.grey.shade200,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: isCompleted
                              ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                              : Text('${index + 1}', style: TextStyle(color: isActive ? Colors.white : AppTheme.textSecondary, fontWeight: FontWeight.bold, fontSize: 12)),
                        ),
                      ),
                      if (index < 3)
                        Expanded(child: Container(height: 2, color: isCompleted ? AppTheme.success : Colors.grey.shade200)),
                    ],
                  ),
                );
              }),
            ),
          ),

          // Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: _buildStepContent(),
            ),
          ),

          // Action Button
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, -5))],
            ),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isProcessing ? null : _onNextStep,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: _currentStep == 3 ? AppTheme.success : AppTheme.primary,
                ),
                child: _isProcessing
                    ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : Text(_currentStep == 3 ? 'Confirm Withdrawal' : 'Continue'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepContent() {
    switch (_currentStep) {
      case 0:
        return _buildAmountStep();
      case 1:
        return _buildMethodStep();
      case 2:
        return _buildReviewStep();
      case 3:
        return _buildConfirmStep();
      default:
        return const SizedBox();
    }
  }

  Widget _buildAmountStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Enter Amount', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 8),
        Text('Available: ₹${_walletData.withdrawableBalance.toStringAsFixed(0)}', style: TextStyle(color: AppTheme.textSecondary)),
        const SizedBox(height: 24),
        
        TextField(
          controller: _amountController,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          decoration: InputDecoration(
            prefixText: '₹ ',
            prefixStyle: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
            hintText: '0',
            filled: true,
            fillColor: AppTheme.backgroundLight,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
          onChanged: (_) => setState(() {}),
        ),
        
        const SizedBox(height: 16),
        
        // Quick Amount Buttons
        Row(
          children: [500, 1000, 2000].map((amount) {
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: OutlinedButton(
                  onPressed: () {
                    _amountController.text = amount.toString();
                    setState(() {});
                  },
                  style: OutlinedButton.styleFrom(side: BorderSide(color: Colors.grey.shade300)),
                  child: Text('₹$amount'),
                ),
              ),
            );
          }).toList(),
        ),
        
        const SizedBox(height: 24),
        
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.info_outline_rounded, color: Colors.blue),
              const SizedBox(width: 12),
              Text('Minimum withdrawal: ₹${WalletService.minWithdrawAmount.toStringAsFixed(0)}', style: const TextStyle(color: Colors.blue)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMethodStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Select Payout Method', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 24),
        
        // UPI Option
        _buildMethodOption(
          PayoutMethod.upi,
          'UPI',
          'Instant transfer',
          Icons.phone_android_rounded,
          Colors.purple,
          true,
        ),
        
        const SizedBox(height: 12),
        
        // Bank Option (Coming Soon)
        _buildMethodOption(
          PayoutMethod.bank,
          'Bank Account',
          'Coming soon',
          Icons.account_balance_rounded,
          Colors.blue,
          false,
        ),
        
        const SizedBox(height: 24),
        
        // UPI ID Input
        if (_selectedMethod == PayoutMethod.upi) ...[
          Text('Enter UPI ID', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          TextField(
            controller: _upiController,
            decoration: InputDecoration(
              hintText: 'yourname@upi',
              prefixIcon: const Icon(Icons.alternate_email_rounded),
              filled: true,
              fillColor: AppTheme.backgroundLight,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
              errorText: _upiError,
            ),
            onChanged: (_) => setState(() => _upiError = null),
          ),
          
          if (_walletData.savedMethods.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Saved UPI IDs', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
            const SizedBox(height: 8),
            ...(_walletData.savedMethods.where((m) => m.type == PayoutMethod.upi).map((method) {
              return GestureDetector(
                onTap: () => setState(() => _upiController.text = method.value),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _upiController.text == method.value ? AppTheme.primary.withOpacity(0.1) : Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _upiController.text == method.value ? AppTheme.primary : Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.check_circle_rounded, color: _upiController.text == method.value ? AppTheme.primary : Colors.grey.shade300, size: 20),
                      const SizedBox(width: 12),
                      Text(method.value),
                    ],
                  ),
                ),
              );
            })),
          ],
        ],
      ],
    );
  }

  Widget _buildMethodOption(PayoutMethod method, String title, String subtitle, IconData icon, Color color, bool enabled) {
    final isSelected = _selectedMethod == method;
    return GestureDetector(
      onTap: enabled ? () => setState(() => _selectedMethod = method) : null,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: enabled ? (isSelected ? color.withOpacity(0.1) : Colors.white) : Colors.grey.shade100,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: isSelected ? color : Colors.grey.shade200),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontWeight: FontWeight.w600, color: enabled ? null : Colors.grey)),
                  Text(subtitle, style: TextStyle(color: enabled ? AppTheme.textSecondary : Colors.grey, fontSize: 13)),
                ],
              ),
            ),
            if (enabled)
              Icon(isSelected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: isSelected ? color : Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildReviewStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Review Details', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 24),
        
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Column(
            children: [
              _buildReviewRow('Withdrawal Amount', '₹${_enteredAmount.toStringAsFixed(0)}'),
              if (_processingFee > 0)
                _buildReviewRow('Processing Fee', '-₹${_processingFee.toStringAsFixed(0)}'),
              const Divider(height: 24),
              _buildReviewRow('Net Amount', '₹${_netAmount.toStringAsFixed(0)}', isBold: true),
              const Divider(height: 24),
              _buildReviewRow('Payout Method', _selectedMethod == PayoutMethod.upi ? 'UPI' : 'Bank'),
              _buildReviewRow('Payout To', _upiController.text),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.warning.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Row(
            children: [
              Icon(Icons.schedule_rounded, color: AppTheme.warning),
              SizedBox(width: 12),
              Expanded(child: Text('Funds will be credited within 24 hours', style: TextStyle(color: AppTheme.warning))),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReviewRow(String label, String value, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: AppTheme.textSecondary)),
          Text(value, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.w600, fontSize: isBold ? 18 : 14)),
        ],
      ),
    );
  }

  Widget _buildConfirmStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Enter PIN', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 8),
        Text('Enter your 4-digit PIN to confirm withdrawal', style: TextStyle(color: AppTheme.textSecondary)),
        const SizedBox(height: 32),
        
        TextField(
          controller: _pinController,
          keyboardType: TextInputType.number,
          obscureText: true,
          maxLength: 4,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 32, letterSpacing: 24, fontWeight: FontWeight.bold),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: InputDecoration(
            counterText: '',
            hintText: '••••',
            filled: true,
            fillColor: AppTheme.backgroundLight,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        
        const SizedBox(height: 16),
        Center(child: Text('Demo PIN: 1234', style: TextStyle(color: AppTheme.textSecondary))),
      ],
    );
  }

  void _onNextStep() {
    if (_currentStep == 0) {
      // Validate amount
      if (_enteredAmount < WalletService.minWithdrawAmount) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Minimum withdrawal is ₹${WalletService.minWithdrawAmount.toStringAsFixed(0)}'), backgroundColor: AppTheme.error),
        );
        return;
      }
      if (_enteredAmount > _walletData.withdrawableBalance) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Amount exceeds withdrawable balance'), backgroundColor: AppTheme.error),
        );
        return;
      }
    } else if (_currentStep == 1) {
      // Validate UPI
      if (!_service.validateUpiId(_upiController.text)) {
        setState(() => _upiError = 'Please enter a valid UPI ID');
        return;
      }
    } else if (_currentStep == 3) {
      // Validate PIN and submit
      if (_pinController.text != '1234') {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invalid PIN. Try 1234'), backgroundColor: AppTheme.error),
        );
        return;
      }
      _processWithdrawal();
      return;
    }

    setState(() => _currentStep++);
  }

  Future<void> _processWithdrawal() async {
    setState(() => _isProcessing = true);

    final success = await _service.initiateWithdrawal(
      amount: _enteredAmount,
      method: _selectedMethod,
      payoutTo: _upiController.text,
    );

    setState(() => _isProcessing = false);

    if (success) {
      _showSuccessDialog();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Withdrawal failed. Please try again.'), backgroundColor: AppTheme.error),
      );
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: AppTheme.success.withOpacity(0.1), shape: BoxShape.circle),
              child: const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 64),
            ),
            const SizedBox(height: 24),
            const Text('Withdrawal Initiated!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('₹${_netAmount.toStringAsFixed(0)} will be credited to ${_upiController.text}', textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary)),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  context.go('/wallet');
                },
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.success, padding: const EdgeInsets.symmetric(vertical: 14)),
                child: const Text('Done'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
