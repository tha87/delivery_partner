enum WithdrawalStatus { pending, processing, success, failed }
enum PayoutMethod { upi, bank }

class WalletData {
  final double availableBalance;
  final double pendingBalance;
  final double withdrawableBalance;
  final WithdrawalRecord? lastWithdrawal;
  final List<SavedPayoutMethod> savedMethods;

  WalletData({
    required this.availableBalance,
    required this.pendingBalance,
    required this.withdrawableBalance,
    this.lastWithdrawal,
    this.savedMethods = const [],
  });
}

class SavedPayoutMethod {
  final String id;
  final PayoutMethod type;
  final String displayName;
  final String value; // UPI ID or masked account number
  final bool isPrimary;

  SavedPayoutMethod({
    required this.id,
    required this.type,
    required this.displayName,
    required this.value,
    this.isPrimary = false,
  });
}

class WithdrawalRecord {
  final String id;
  final DateTime dateTime;
  final double amount;
  final double processingFee;
  final double netAmount;
  final PayoutMethod method;
  final String payoutTo;
  final WithdrawalStatus status;
  final String? failureReason;

  WithdrawalRecord({
    required this.id,
    required this.dateTime,
    required this.amount,
    this.processingFee = 0,
    required this.netAmount,
    required this.method,
    required this.payoutTo,
    required this.status,
    this.failureReason,
  });
}

class WalletService {
  static const double minWithdrawAmount = 100.0;
  static const double processingFeePercent = 0.0; // Free for now

  WalletData getWalletData() {
    final now = DateTime.now();
    return WalletData(
      availableBalance: 2450.0,
      pendingBalance: 350.0,
      withdrawableBalance: 2450.0,
      lastWithdrawal: WithdrawalRecord(
        id: 'WD-1001',
        dateTime: now.subtract(const Duration(days: 1)),
        amount: 1000.0,
        netAmount: 1000.0,
        method: PayoutMethod.upi,
        payoutTo: 'driver@upi',
        status: WithdrawalStatus.success,
      ),
      savedMethods: [
        SavedPayoutMethod(
          id: '1',
          type: PayoutMethod.upi,
          displayName: 'Primary UPI',
          value: 'driver@upi',
          isPrimary: true,
        ),
      ],
    );
  }

  List<WithdrawalRecord> getWithdrawalHistory() {
    final now = DateTime.now();
    return [
      WithdrawalRecord(
        id: 'WD-1005',
        dateTime: now.subtract(const Duration(hours: 2)),
        amount: 500.0,
        netAmount: 500.0,
        method: PayoutMethod.upi,
        payoutTo: 'driver@upi',
        status: WithdrawalStatus.pending,
      ),
      WithdrawalRecord(
        id: 'WD-1004',
        dateTime: now.subtract(const Duration(days: 1)),
        amount: 1000.0,
        netAmount: 1000.0,
        method: PayoutMethod.upi,
        payoutTo: 'driver@upi',
        status: WithdrawalStatus.success,
      ),
      WithdrawalRecord(
        id: 'WD-1003',
        dateTime: now.subtract(const Duration(days: 3)),
        amount: 750.0,
        netAmount: 750.0,
        method: PayoutMethod.upi,
        payoutTo: 'driver@upi',
        status: WithdrawalStatus.success,
      ),
      WithdrawalRecord(
        id: 'WD-1002',
        dateTime: now.subtract(const Duration(days: 5)),
        amount: 600.0,
        netAmount: 600.0,
        method: PayoutMethod.upi,
        payoutTo: 'old@upi',
        status: WithdrawalStatus.failed,
        failureReason: 'Invalid UPI ID',
      ),
      WithdrawalRecord(
        id: 'WD-1001',
        dateTime: now.subtract(const Duration(days: 10)),
        amount: 1200.0,
        netAmount: 1200.0,
        method: PayoutMethod.upi,
        payoutTo: 'driver@upi',
        status: WithdrawalStatus.success,
      ),
    ];
  }

  bool validateUpiId(String upi) {
    final regex = RegExp(r'^[\w.\-_]+@[\w.\-]+$');
    return regex.hasMatch(upi);
  }

  Future<bool> initiateWithdrawal({
    required double amount,
    required PayoutMethod method,
    required String payoutTo,
  }) async {
    // Mock API call
    await Future.delayed(const Duration(seconds: 2));
    return true;
  }
}
