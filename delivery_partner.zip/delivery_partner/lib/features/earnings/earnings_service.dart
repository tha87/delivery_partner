class EarningsData {
  final double baseEarnings;
  final double incentives;
  final double bonuses;
  final double tips;
  final double penalties;
  final double netEarnings;
  final int totalDeliveries;
  final int successfulDeliveries;
  final int failedDeliveries;
  final double averageRating;
  final List<EarningTransaction> transactions;
  final List<IncentiveSlab> incentiveSlabs;
  final PayoutInfo payoutInfo;

  EarningsData({
    required this.baseEarnings,
    required this.incentives,
    required this.bonuses,
    required this.tips,
    required this.penalties,
    required this.netEarnings,
    required this.totalDeliveries,
    required this.successfulDeliveries,
    required this.failedDeliveries,
    required this.averageRating,
    required this.transactions,
    required this.incentiveSlabs,
    required this.payoutInfo,
  });
}

class EarningTransaction {
  final String id;
  final String type; // 'delivery', 'incentive', 'bonus', 'tip', 'penalty'
  final String description;
  final double amount;
  final DateTime timestamp;
  final bool isCredit;

  EarningTransaction({
    required this.id,
    required this.type,
    required this.description,
    required this.amount,
    required this.timestamp,
    required this.isCredit,
  });
}

class IncentiveSlab {
  final int minDeliveries;
  final int maxDeliveries;
  final double bonusAmount;
  final bool isAchieved;
  final int currentProgress;

  IncentiveSlab({
    required this.minDeliveries,
    required this.maxDeliveries,
    required this.bonusAmount,
    required this.isAchieved,
    required this.currentProgress,
  });

  double get progressPercentage => (currentProgress / maxDeliveries).clamp(0.0, 1.0);
}

class PayoutInfo {
  final String linkedUpiId;
  final double pendingAmount;
  final double processedToday;
  final String payoutFrequency; // 'daily', 'weekly'
  final DateTime? lastPayoutDate;
  final double lastPayoutAmount;

  PayoutInfo({
    required this.linkedUpiId,
    required this.pendingAmount,
    required this.processedToday,
    required this.payoutFrequency,
    this.lastPayoutDate,
    required this.lastPayoutAmount,
  });
}

class EarningsService {
  EarningsData getTodayEarnings() {
    final now = DateTime.now();
    return EarningsData(
      baseEarnings: 600.0,
      incentives: 150.0,
      bonuses: 100.0,
      tips: 75.0,
      penalties: 25.0,
      netEarnings: 900.0,
      totalDeliveries: 15,
      successfulDeliveries: 14,
      failedDeliveries: 1,
      averageRating: 4.7,
      transactions: [
        EarningTransaction(
          id: '1',
          type: 'delivery',
          description: 'Delivery #ORD-1015',
          amount: 50.0,
          timestamp: now.subtract(const Duration(hours: 1)),
          isCredit: true,
        ),
        EarningTransaction(
          id: '2',
          type: 'tip',
          description: 'Customer Tip - #ORD-1015',
          amount: 25.0,
          timestamp: now.subtract(const Duration(hours: 1)),
          isCredit: true,
        ),
        EarningTransaction(
          id: '3',
          type: 'delivery',
          description: 'Delivery #ORD-1014',
          amount: 50.0,
          timestamp: now.subtract(const Duration(hours: 2)),
          isCredit: true,
        ),
        EarningTransaction(
          id: '4',
          type: 'penalty',
          description: 'Late Delivery - #ORD-1012',
          amount: 25.0,
          timestamp: now.subtract(const Duration(hours: 3)),
          isCredit: false,
        ),
        EarningTransaction(
          id: '5',
          type: 'incentive',
          description: '10 Deliveries Milestone',
          amount: 100.0,
          timestamp: now.subtract(const Duration(hours: 4)),
          isCredit: true,
        ),
        EarningTransaction(
          id: '6',
          type: 'bonus',
          description: 'Peak Hour Bonus',
          amount: 50.0,
          timestamp: now.subtract(const Duration(hours: 5)),
          isCredit: true,
        ),
      ],
      incentiveSlabs: [
        IncentiveSlab(
          minDeliveries: 1,
          maxDeliveries: 5,
          bonusAmount: 25.0,
          isAchieved: true,
          currentProgress: 15,
        ),
        IncentiveSlab(
          minDeliveries: 6,
          maxDeliveries: 10,
          bonusAmount: 75.0,
          isAchieved: true,
          currentProgress: 15,
        ),
        IncentiveSlab(
          minDeliveries: 11,
          maxDeliveries: 15,
          bonusAmount: 150.0,
          isAchieved: true,
          currentProgress: 15,
        ),
        IncentiveSlab(
          minDeliveries: 16,
          maxDeliveries: 20,
          bonusAmount: 250.0,
          isAchieved: false,
          currentProgress: 15,
        ),
      ],
      payoutInfo: PayoutInfo(
        linkedUpiId: 'driver@upi',
        pendingAmount: 900.0,
        processedToday: 0.0,
        payoutFrequency: 'daily',
        lastPayoutDate: now.subtract(const Duration(days: 1)),
        lastPayoutAmount: 850.0,
      ),
    );
  }

  EarningsData getWeeklyEarnings() {
    final now = DateTime.now();
    return EarningsData(
      baseEarnings: 4200.0,
      incentives: 850.0,
      bonuses: 500.0,
      tips: 425.0,
      penalties: 75.0,
      netEarnings: 5900.0,
      totalDeliveries: 98,
      successfulDeliveries: 95,
      failedDeliveries: 3,
      averageRating: 4.6,
      transactions: [],
      incentiveSlabs: [],
      payoutInfo: PayoutInfo(
        linkedUpiId: 'driver@upi',
        pendingAmount: 900.0,
        processedToday: 5000.0,
        payoutFrequency: 'daily',
        lastPayoutDate: now.subtract(const Duration(days: 1)),
        lastPayoutAmount: 850.0,
      ),
    );
  }
}
