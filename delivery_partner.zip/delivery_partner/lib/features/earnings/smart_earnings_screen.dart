import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import '../../core/app_theme.dart';
import 'earnings_service.dart';

class SmartEarningsScreen extends StatefulWidget {
  const SmartEarningsScreen({super.key});

  @override
  State<SmartEarningsScreen> createState() => _SmartEarningsScreenState();
}

class _SmartEarningsScreenState extends State<SmartEarningsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final EarningsService _service = EarningsService();
  late EarningsData _todayData;
  late EarningsData _weeklyData;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _todayData = _service.getTodayEarnings();
    _weeklyData = _service.getWeeklyEarnings();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Earnings'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => context.pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.download_rounded),
            onPressed: () => _showExportDialog(),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppTheme.primary,
          labelColor: AppTheme.primary,
          unselectedLabelColor: AppTheme.textSecondary,
          tabs: const [
            Tab(text: 'Today'),
            Tab(text: 'This Week'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildEarningsView(_todayData),
          _buildEarningsView(_weeklyData),
        ],
      ),
      bottomNavigationBar: _buildPayoutBar(),
    );
  }

  Widget _buildEarningsView(EarningsData data) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Net Earnings Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: AppTheme.accentGradient,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.accent.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              children: [
                const Text('Net Earnings', style: TextStyle(color: Colors.white70, fontSize: 16)),
                const SizedBox(height: 8),
                Text(
                  '₹${data.netEarnings.toStringAsFixed(0)}',
                  style: const TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildMiniStat('${data.successfulDeliveries}', 'Deliveries'),
                    Container(width: 1, height: 30, color: Colors.white30, margin: const EdgeInsets.symmetric(horizontal: 20)),
                    _buildMiniStat('${data.averageRating}', 'Rating'),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Earnings Breakdown
          Text('Breakdown', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              children: [
                _buildBreakdownRow('Base Earnings', data.baseEarnings, AppTheme.textPrimary),
                _buildBreakdownRow('Incentives', data.incentives, AppTheme.success),
                _buildBreakdownRow('Bonuses', data.bonuses, AppTheme.primary),
                _buildBreakdownRow('Tips', data.tips, AppTheme.accent),
                if (data.penalties > 0)
                  _buildBreakdownRow('Penalties', -data.penalties, AppTheme.error),
                const Divider(),
                _buildBreakdownRow('Net Total', data.netEarnings, AppTheme.textPrimary, isBold: true),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Incentive Slabs
          if (data.incentiveSlabs.isNotEmpty) ...[
            Text('Incentive Slabs', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...data.incentiveSlabs.map((slab) => _buildIncentiveSlab(slab)),
          ],

          const SizedBox(height: 24),

          // Recent Transactions
          if (data.transactions.isNotEmpty) ...[
            Text('Recent Activity', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            ...data.transactions.map((tx) => _buildTransactionItem(tx)),
          ],

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildMiniStat(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ],
    );
  }

  Widget _buildBreakdownRow(String label, double amount, Color color, {bool isBold = false}) {
    final isNegative = amount < 0;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: color, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text(
            '${isNegative ? '-' : '+'}₹${amount.abs().toStringAsFixed(0)}',
            style: TextStyle(
              color: isNegative ? AppTheme.error : color,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
              fontSize: isBold ? 18 : 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIncentiveSlab(IncentiveSlab slab) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: slab.isAchieved ? AppTheme.success.withOpacity(0.1) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: slab.isAchieved ? AppTheme.success.withOpacity(0.3) : Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${slab.minDeliveries}-${slab.maxDeliveries} Deliveries',
                style: TextStyle(fontWeight: FontWeight.w600, color: slab.isAchieved ? AppTheme.success : AppTheme.textPrimary),
              ),
              Row(
                children: [
                  Text(
                    '+₹${slab.bonusAmount.toStringAsFixed(0)}',
                    style: TextStyle(color: slab.isAchieved ? AppTheme.success : AppTheme.textSecondary, fontWeight: FontWeight.bold),
                  ),
                  if (slab.isAchieved) ...[
                    const SizedBox(width: 8),
                    const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 18),
                  ],
                ],
              ),
            ],
          ),
          if (!slab.isAchieved) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: slab.progressPercentage,
                backgroundColor: Colors.grey.shade200,
                valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primary),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '${slab.currentProgress}/${slab.maxDeliveries} deliveries',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTransactionItem(EarningTransaction tx) {
    final timeFormat = DateFormat('hh:mm a');
    IconData icon;
    Color color;

    switch (tx.type) {
      case 'delivery':
        icon = Icons.local_shipping_rounded;
        color = AppTheme.primary;
        break;
      case 'tip':
        icon = Icons.star_rounded;
        color = AppTheme.accent;
        break;
      case 'incentive':
        icon = Icons.emoji_events_rounded;
        color = AppTheme.warning;
        break;
      case 'bonus':
        icon = Icons.celebration_rounded;
        color = AppTheme.success;
        break;
      case 'penalty':
        icon = Icons.warning_rounded;
        color = AppTheme.error;
        break;
      default:
        icon = Icons.receipt_rounded;
        color = AppTheme.textSecondary;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tx.description, style: const TextStyle(fontWeight: FontWeight.w500)),
                Text(timeFormat.format(tx.timestamp), style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
              ],
            ),
          ),
          Text(
            '${tx.isCredit ? '+' : '-'}₹${tx.amount.toStringAsFixed(0)}',
            style: TextStyle(
              color: tx.isCredit ? AppTheme.success : AppTheme.error,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPayoutBar() {
    final payout = _todayData.payoutInfo;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Pending Payout', style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                Text('₹${payout.pendingAmount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              ],
            ),
          ),
          ElevatedButton.icon(
            onPressed: () => _showPayoutDialog(),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.success,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            icon: const Icon(Icons.flash_on_rounded),
            label: const Text('Instant Payout'),
          ),
        ],
      ),
    );
  }

  void _showPayoutDialog() {
    final payout = _todayData.payoutInfo;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            const Icon(Icons.account_balance_wallet_rounded, size: 48, color: AppTheme.success),
            const SizedBox(height: 16),
            Text('Instant Payout', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('₹${payout.pendingAmount.toStringAsFixed(0)}', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.backgroundLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.account_balance_rounded, color: AppTheme.primary),
                  const SizedBox(width: 12),
                  Text(payout.linkedUpiId, style: const TextStyle(fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Payout initiated! Amount will be credited shortly.'),
                      backgroundColor: AppTheme.success,
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.success,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Transfer to UPI'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showExportDialog() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 24),
            Text('Export Earnings', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 20),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.error.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.picture_as_pdf_rounded, color: AppTheme.error),
              ),
              title: const Text('Export as PDF'),
              subtitle: const Text('Detailed earnings report'),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('PDF exported successfully!'),
                    backgroundColor: AppTheme.success,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
            ListTile(
              leading: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.table_chart_rounded, color: AppTheme.success),
              ),
              title: const Text('Export as CSV'),
              subtitle: const Text('For spreadsheet analysis'),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('CSV exported successfully!'),
                    backgroundColor: AppTheme.success,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
